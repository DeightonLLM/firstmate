#!/usr/bin/env python3
"""
Music Metrics VPS Worker
Runs from systemd timer to process lead enrichment queue.
"""

import os
import sys
import json
import time
import re
import socket
import urllib.request
import urllib.error
import fcntl

# Constants & Paths
LOCK_FILE = '/tmp/music_worker.lock'
STATE_FILE = '/root/logs/music_worker.state'
LOG_FILE = '/root/logs/music_worker.log'

CPANEL_TOKEN_FILE = '/root/.secrets/saas_db_probe_token_music'
REPLICATE_TOKEN_FILE = '/root/.secrets/music_metrics_replicate_key_new.txt'

STATUS_URL = 'https://music-metrics.com/worker_status.php'
PAUSE_URL = 'https://music-metrics.com/worker_pause.php'
CLAIM_URL = 'https://music-metrics.com/queue_claim.php'
RESULT_URL = 'https://music-metrics.com/scrape_result.php'

MODEL_VERSION = 'e4321bcdf8cc522da43519a17baf748c675710bad1d3db9f57aaad29f805ac19'

# ----------------------------------------------------------------------------
# Layer B — circuit breaker + rate cap (MUSIC_RESOURCE_OVERUSE_GLM52_20260809)
# ----------------------------------------------------------------------------
# 403/429/5xx and transport failure (0) count toward the circuit breaker.
# 401 still halts permanently. After CIRCUIT_FAIL_THRESHOLD consecutive infra
# failures the circuit opens for an exponentially-increasing cooldown
# (CIRCUIT_COOLDOWN_INITIAL * 2^level, capped at CIRCUIT_COOLDOWN_MAX). The
# circuit never auto-resets on a 2xx — only the cooldown expiry or a manual
# reset (delete state file / set circuit_open_until=0) re-arms the worker.
CIRCUIT_FAIL_THRESHOLD = 3
CIRCUIT_COOLDOWN_INITIAL = 600   # 10 min
CIRCUIT_COOLDOWN_MAX = 3600      # 1 hour
INFRA_FAIL_CODES = frozenset({0, 403, 429, 500, 502, 503, 504})

# Rate cap (Layer B.2). Always active — independent of the circuit breaker.
# Hourly batch cap uses a sliding 1-hour window. Min gap is a strict floor on
# time between non-empty batches. Daily lead cap is absolute.
MAX_BATCHES_PER_HOUR = 3
MIN_BATCH_GAP_SEC = 1200     # 20 min
MAX_LEADS_PER_DAY = 120
MAX_LEADS_PER_RUN = 5        # local hard cap regardless of server response

# Spam Filtering Lists & RegEx
SPAM_DOMAINS = [
    'sentry.io', 'sentry.wixpress.com', 'sentry-next.wixpress.com',
    'wixpress.com', 'example.com', 'sentry.', 'noreply', 'no-reply',
    'localhost', 'test.com', 'email.com', 'domain.com', 'yoursite.com',
    'company.com', 'website.com', 'sample.com', 'placeholder',
    'wordpress.org', 'wordpress.com', 'w3.org', 'schema.org',
    'googleusercontent.com', 'gstatic.com', 'googleapis.com',
    'apple.com', 'icloud.com', 'microsoft.com', 'outlook.com',
    'squarespace.com', 'weebly.com', 'shopify.com', 'wix.com',
    'godaddy.com', 'cloudflare.com', 'group.calendar.google.com',
    'calendar.google.com', 'mysite.com', 'mywebsite.com', 'mycompany.com',
    'mydomain.com', 'address.com', 'company.site', 'yourcompany.com',
    'yourdomain.com', 'yourname.com', 'sitebuilder.com', 'templatemonster.com'
]

SPAM_PATTERNS = [
    r'^.{0,2}@',
    r'^\.\+@',
    r'@\d+\.\d+',
    r'^[a-f0-9]{20,}@',
    r'^[0-9]+@',
    r'\.(js|css|php|html|json|xml|svg|png|jpg|jpeg|gif|webp|avif|bmp|ico|woff|woff2|ttf|eot|otf|mp4|mp3|pdf|zip|doc|docx)$',
    r'@.*@',
    r'^(admin|info|support|contact|hello|help|sales|billing|abuse|postmaster|webmaster|hostmaster|mailer-daemon|noreply|no-reply)@(gmail|yahoo|hotmail|outlook)\.',
    r'^(example|test|user|name|email|your|sample|demo|placeholder|changeme|first\.?last|john\.?doe|jane\.?doe)@',
    r'^[a-z0-9]{25,}@',
    r'@group\.calendar\.'
]

SOCIAL_DOMAINS = [
    'facebook.com', 'fb.com', 'fb.me',
    'instagram.com', 'instagr.am',
    'twitter.com', 'x.com',
    'linkedin.com',
    'youtube.com', 'youtu.be',
    'tiktok.com',
    'pinterest.com',
    'yelp.com'
]

def log(msg):
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, 'a') as f:
            f.write(line + '\n')
    except OSError:
        pass

def load_secret(path):
    try:
        with open(path, 'r') as f:
            return f.read().strip()
    except OSError:
        return ''

def get_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {
        'consecutive_empty': 0,
        'allowed_run_time': 0,
        'halted': False,
        # Circuit breaker (Layer B.1)
        'circuit_fail_count': 0,
        'circuit_open_until': 0,
        'circuit_cooldown_level': 0,
        'circuit_open_reason': '',
        # Rate cap (Layer B.2)
        'batch_times': [],
        'batches_today': 0,
        'leads_today': 0,
        'day_stamp': '',
        'last_batch_finished_at': 0,
    }

def is_infra_failure(code):
    return code in INFRA_FAIL_CODES

def record_infra_failure(state, reason):
    """Mark an infra failure. If CIRCUIT_FAIL_THRESHOLD is reached, open the
    circuit with exponential cooldown. Persistence to STATE_FILE is unconditional;
    a worker exit after this call will preserve the open circuit across runs."""
    fail_count = state.get('circuit_fail_count', 0) + 1
    state['circuit_fail_count'] = fail_count
    if fail_count >= CIRCUIT_FAIL_THRESHOLD:
        level = state.get('circuit_cooldown_level', 0)
        cooldown = min(CIRCUIT_COOLDOWN_INITIAL * (2 ** level), CIRCUIT_COOLDOWN_MAX)
        state['circuit_open_until'] = time.time() + cooldown
        state['circuit_cooldown_level'] = level + 1
        state['circuit_open_reason'] = reason
        log(f"CIRCUIT OPENED: {reason} (fails={fail_count}); cooldown={cooldown}s level={level + 1}")
    else:
        log(f"INFRA FAIL {fail_count}/{CIRCUIT_FAIL_THRESHOLD}: {reason}")
    save_state(state)
    return state

def clear_infra_failures(state):
    """Successful 2xx from a worker_status/queue_claim clears the fail tally.
    The circuit_open_until is NOT cleared here — only the cooldown expiry or a
    manual reset (delete state file / set circuit_open_until=0) re-arms the
    worker. This guarantees a 403 cannot be retried every timer tick."""
    if state.get('circuit_fail_count', 0) > 0 or state.get('circuit_cooldown_level', 0) > 0:
        log("CIRCUIT RESET: successful 2xx; clearing failure tally (cooldown still active if open)")
        state['circuit_fail_count'] = 0
        state['circuit_cooldown_level'] = 0
    return state

def check_rate_cap(state):
    """Apply hourly batch cap (sliding 1-hour window) + min gap + daily lead cap.
    Returns True if a batch may run; returns False after setting allowed_run_time
    to the next allowed moment and saving state."""
    now = time.time()
    today = time.strftime('%Y-%m-%d')
    if state.get('day_stamp') != today:
        state['day_stamp'] = today
        state['batches_today'] = 0
        state['leads_today'] = 0
    # Sliding-window prune of batch_times (last 60 min)
    batch_times = [t for t in state.get('batch_times', []) if now - t < 3600]
    state['batch_times'] = batch_times
    # Daily lead cap
    if state.get('leads_today', 0) >= MAX_LEADS_PER_DAY:
        next_midnight = (int(now) // 86400 + 1) * 86400
        state['allowed_run_time'] = next_midnight
        log(f"RATE LIMIT: daily lead budget exhausted ({state['leads_today']}/{MAX_LEADS_PER_DAY}); next run after midnight")
        save_state(state)
        return False
    # Hourly batch cap
    if len(batch_times) >= MAX_BATCHES_PER_HOUR:
        state['allowed_run_time'] = batch_times[0] + 3600
        log(f"RATE LIMIT: hourly batch cap reached ({len(batch_times)}/{MAX_BATCHES_PER_HOUR})")
        save_state(state)
        return False
    # Min gap (only enforced between batches that actually did work)
    if batch_times and (now - batch_times[-1]) < MIN_BATCH_GAP_SEC:
        state['allowed_run_time'] = batch_times[-1] + MIN_BATCH_GAP_SEC
        log(f"RATE LIMIT: min gap not satisfied ({int(now - batch_times[-1])}s < {MIN_BATCH_GAP_SEC}s)")
        save_state(state)
        return False
    return True

def record_batch_run(state, lead_count):
    """Called after a non-empty batch finishes. Updates sliding window, daily
    tallies, and last-finish timestamp."""
    state['batch_times'] = (state.get('batch_times', []) + [time.time()])[-20:]
    state['batches_today'] = state.get('batches_today', 0) + 1
    state['leads_today'] = state.get('leads_today', 0) + lead_count
    state['last_batch_finished_at'] = time.time()

def save_state(state):
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f)
    except OSError:
        pass

def parse_emails(html):
    if not html:
        return []
    matches = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', html)
    unique_emails = list(set(matches))
    clean = []
    for email in unique_emails:
        email = email.lower().strip()
        if len(email) < 6 or len(email) > 254:
            continue
        is_spam = False
        for sd in SPAM_DOMAINS:
            if sd in email:
                is_spam = True
                break
        if is_spam:
            continue
        for pat in SPAM_PATTERNS:
            if re.search(pat, email, re.IGNORECASE):
                is_spam = True
                break
        if is_spam:
            continue
        parts = email.split('@')
        if len(parts) != 2:
            continue
        local, domain = parts
        if len(local) < 2 or len(local) > 64:
            continue
        if domain.count('.') < 1:
            continue
        if re.match(r'^\d+\.\d+\.\d+$', domain):
            continue
        if re.match(r'^[a-f0-9]{24,}$', local):
            continue
        if not re.match(r'^[a-zA-Z]', local):
            continue
        clean.append(email)
    return clean[:10]

def parse_socials(html):
    if not html:
        return []
    matches = re.findall(r'https?://[^\s"\'<>]+', html)
    socials = []
    for url in list(set(matches)):
        for domain in SOCIAL_DOMAINS:
            if domain in url:
                clean = re.sub(r'["\'>)}\]]+$', '', url)
                if len(clean) > len(domain) + 12:
                    socials.append(clean)
                break
    return list(set(socials))[:20]

def make_request(url, method='GET', data=None, headers=None, timeout=30):
    if headers is None:
        headers = {}
    payload = None
    if data is not None:
        payload = json.dumps(data).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    
    req = urllib.request.Request(url, data=payload, headers=headers, method=method)
    # Retry transient connection/DNS/TLS/timeout failures (HTTP 0) with [1s, 2s, 4s] backoff.
    # Catches urllib.error.URLError (DNS/connect/refused) + TimeoutError + socket.timeout
    # (Python 3.10+ raises TimeoutError directly at socket layer; socket.timeout is its alias).
    # HTTPError (real server response) is NOT retried — that is a legitimate signal.
    import time as _retry_time
    _retry_backoff = [1, 2, 4]
    last_exc = None
    for _attempt, _delay in enumerate(_retry_backoff + [0], start=1):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.status, resp.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode('utf-8')
        except (urllib.error.URLError, TimeoutError, socket.timeout) as e:
            last_exc = e
            if _delay:
                log(f"make_request transient fail attempt {_attempt}/4 {type(e).__name__}; sleep {_delay}s")
                _retry_time.sleep(_delay)
            else:
                log(f"make_request transient fail attempt {_attempt}/4 {type(e).__name__}; retries exhausted")
    return 0, str(last_exc)

def trigger_replicate(website_url, replicate_token):
    payload = {
        'version': MODEL_VERSION,
        'input': {'url': website_url}
    }
    headers = {
        'Authorization': f"Bearer {replicate_token}",
        'Content-Type': 'application/json'
    }
    req = urllib.request.Request(
        'https://api.replicate.com/v1/predictions',
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            if resp.status == 201 or resp.status == 200:
                res_data = json.loads(resp.read().decode('utf-8'))
                return True, res_data.get('id', ''), ''
            return False, '', f"HTTP {resp.status}"
    except urllib.error.HTTPError as e:
        try:
            err_data = json.loads(e.read().decode('utf-8'))
            detail = err_data.get('detail', f"HTTP {e.code}")
        except Exception:
            detail = f"HTTP {e.code}"
        return False, '', detail
    except Exception as e:
        return False, '', str(e)

def poll_replicate(prediction_id, replicate_token, timeout_sec=45):
    headers = {
        'Authorization': f"Bearer {replicate_token}"
    }
    url = f"https://api.replicate.com/v1/predictions/{prediction_id}"
    req = urllib.request.Request(url, headers=headers, method='GET')
    
    start_time = time.time()
    while time.time() - start_time < timeout_sec:
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    status = data.get('status')
                    if status == 'succeeded':
                        output = data.get('output', {})
                        html = output.get('html_content') or output.get('text_content') or ''
                        return True, html, ''
                    elif status in ['failed', 'canceled']:
                        return False, '', f"Replicate status: {status}"
        except Exception as e:
            log(f"  WARN: Poll exception for prediction {prediction_id}: {e}")
        time.sleep(3)
    return False, '', "TIMEOUT"

def main():
    # 1. Enforce lockfile
    lock_file = open(LOCK_FILE, 'w')
    try:
        fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("Worker lock collision. Exiting.")
        sys.exit(0)

    # 2. Check state and backoff
    state = get_state()
    if state.get('halted'):
        log("HALTED: Credentials validation failed. Manual reset required.")
        sys.exit(0)

    # 2a. Circuit breaker — if open, do not contact host. Cooldown is in
    # state['circuit_open_until'] (epoch seconds). Manual reset = delete state
    # file or set circuit_open_until=0. Auto-reset on 2xx is intentionally NOT
    # applied here so that a 403 cannot be retried every timer tick.
    circuit_open_until = state.get('circuit_open_until', 0)
    if time.time() < circuit_open_until:
        log(f"CIRCUIT OPEN: cooldown active (reason={state.get('circuit_open_reason', '')!r}) until {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(circuit_open_until))}; exiting without host contact")
        sys.exit(0)

    allowed_run_time = state.get('allowed_run_time', 0)
    if time.time() < allowed_run_time:
        sys.exit(0)

    # 3. Read auth token
    api_token = load_secret(CPANEL_TOKEN_FILE)
    if not api_token:
        log("CRITICAL: API Token not found locally.")
        sys.exit(1)

    # 4. Check worker status (worker_status.php requires X-API-Token per S-C2 audit fix)
    headers = {'X-API-Token': api_token}
    status_code, body = make_request(STATUS_URL, headers=headers)
    if status_code != 200:
        if is_infra_failure(status_code):
            record_infra_failure(state, f"worker_status HTTP {status_code}")
        else:
            save_state(state)
        log(f"CRITICAL: Failed to query status. HTTP {status_code}")
        sys.exit(1)

    # 200 OK from worker_status — clear failure tally (cooldown still active if open)
    state = clear_infra_failures(state)

    try:
        status_data = json.loads(body)
    except Exception:
        log("CRITICAL: Failed to parse status response.")
        sys.exit(1)

    if status_data.get('worker_paused') is True:
        log(f"PAUSED: Skipping execution. Reason: {status_data.get('pause_reason')}")
        sys.exit(0)

    # 5. Attempt queue claim
    code, claim_body = make_request(CLAIM_URL, method='POST', data={}, headers=headers)

    if code == 401:
        log("CRITICAL: 401 Unauthorized. Halting worker execution permanently.")
        state['halted'] = True
        save_state(state)
        sys.exit(1)

    if code == 403:
        # 403 from queue_claim counts toward the circuit breaker.
        record_infra_failure(state, "queue_claim HTTP 403")
        log("PAUSED: 403 Forbidden. Queue claim paused.")
        sys.exit(0)

    if code != 200:
        if is_infra_failure(code):
            record_infra_failure(state, f"queue_claim HTTP {code}")
        else:
            save_state(state)
        log(f"ERROR: Queue claim failed. HTTP {code}")
        sys.exit(1)

    # 200 OK from queue_claim — clear failure tally
    state = clear_infra_failures(state)

    try:
        claim_data = json.loads(claim_body)
    except Exception:
        log("ERROR: Failed to parse queue claim JSON response.")
        sys.exit(1)

    worker_run_id = claim_data.get('worker_run_id')
    leads = claim_data.get('leads', [])

    # 6. Stateful empty queue backoff
    if not leads:
        consec = state.get('consecutive_empty', 0) + 1
        state['consecutive_empty'] = consec

        # Calculate backoff
        if consec == 1:
            delay = 60
        elif consec == 2:
            delay = 300
        elif consec == 3:
            delay = 600
        else:
            delay = 900

        state['allowed_run_time'] = time.time() + delay
        save_state(state)
        log(f"Queue empty. Consecutive={consec}. Next poll allowed in {delay}s.")
        sys.exit(0)

    # Layer B.2 — rate cap. Apply BEFORE doing any work so the queue is not
    # hammered even when the server keeps handing us full batches.
    if not check_rate_cap(state):
        # check_rate_cap already saved state with allowed_run_time set
        log(f"Rate cap blocked batch of {len(leads)} leads; respecting allowed_run_time")
        sys.exit(0)

    # Layer B.2 — local hard batch cap. Truncate whatever the server returned
    # to MAX_LEADS_PER_RUN so a misconfigured server cannot force a hammer run.
    if len(leads) > MAX_LEADS_PER_RUN:
        log(f"BATCH TRUNCATED: server returned {len(leads)} leads; truncating to MAX_LEADS_PER_RUN={MAX_LEADS_PER_RUN}")
        leads = leads[:MAX_LEADS_PER_RUN]

    # Reset backoff counters since queue has items
    state['consecutive_empty'] = 0
    state['allowed_run_time'] = 0
    save_state(state)

    replicate_token = load_secret(REPLICATE_TOKEN_FILE)
    if not replicate_token:
        log("CRITICAL: Replicate API token not found on VPS.")
        sys.exit(1)

    log(f"Processing batch of {len(leads)} leads. RunID={worker_run_id}")
    
    consecutive_errors = 0
    success_count = 0

    for lead in leads:
        lead_id = lead['id']
        list_id = lead['list_id']
        website = lead['website'] or ''
        
        log(f" Lead ID {lead_id}: {website}")
        
        # Format URL
        url = website.strip()
        if not re.match(r'^https?://', url, re.IGNORECASE):
            url = 'https://' + url

        # A. Trigger Replicate
        ok, prediction_id, err_msg = trigger_replicate(url, replicate_token)
        if not ok:
            log(f"   TRIGGER FAILED: {err_msg}")
            consecutive_errors += 1
            # Submit failure result
            result_payload = {
                'worker_run_id': worker_run_id,
                'lead_id': lead_id,
                'list_id': list_id,
                'status': 'failed',
                'error': err_msg
            }
            make_request(RESULT_URL, method='POST', data=result_payload, headers=headers)
            continue

        log(f"   Triggered prediction_id: {prediction_id}")

        # B. Poll Replicate for completion
        poll_ok, html_content, poll_err = poll_replicate(prediction_id, replicate_token)
        if not poll_ok:
            log(f"   POLLING FAILED: {poll_err}")
            consecutive_errors += 1
            result_payload = {
                'worker_run_id': worker_run_id,
                'lead_id': lead_id,
                'list_id': list_id,
                'status': 'failed',
                'error': poll_err
            }
            make_request(RESULT_URL, method='POST', data=result_payload, headers=headers)
            continue

        # C. Parse outputs
        emails = parse_emails(html_content)
        socials = parse_socials(html_content)
        log(f"   SUCCESS: emails={len(emails)} socials={len(socials)}")
        success_count += 1
        consecutive_errors = 0 # reset error tally on row success

        # D. Post results
        result_payload = {
            'worker_run_id': worker_run_id,
            'lead_id': lead_id,
            'list_id': list_id,
            'status': 'succeeded',
            'emails': emails,
            'socials': socials
        }
        res_code, res_body = make_request(RESULT_URL, method='POST', data=result_payload, headers=headers)
        if res_code != 200:
            # Layer B.1 — DB-touching endpoint failures count toward the
            # circuit breaker, not only Replicate failures.
            if is_infra_failure(res_code):
                record_infra_failure(state, f"scrape_result HTTP {res_code}")
            log(f"   WARN: Submit results failed with HTTP {res_code}: {res_body}")

        # Throttling delay
        time.sleep(3)

        # 7. Check failure throttling thresholds
        if consecutive_errors >= 4:
            log("CRITICAL: Encountered 4 consecutive scraping failures. Pausing worker settings.")
            pause_payload = {'reason': 'consecutive_errors'}
            make_request(PAUSE_URL, method='POST', data=pause_payload, headers=headers)
            break

    log(f"Batch completed. Success={success_count}/{len(leads)}")

    # Layer B.2 — record this batch for the sliding rate cap so the next
    # non-empty tick is forced through MIN_BATCH_GAP_SEC and the hourly / daily
    # counters are advanced. Only record non-empty batches: empty-queue backoff
    # is governed by the existing consecutive_empty ladder and must not consume
    # hourly budget.
    record_batch_run(state, len(leads))
    save_state(state)

if __name__ == '__main__':
    main()
