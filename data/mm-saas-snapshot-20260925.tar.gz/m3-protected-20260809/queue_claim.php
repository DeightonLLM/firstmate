<?php
/**
 * Queue Claiming Endpoint - Authenticated
 * Atomically locks and claims up to 5 pending leads using FOR UPDATE.
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'METHOD_NOT_ALLOWED']);
    exit;
}

// 1. Load expected DB_SCHEMA_PROBE_TOKEN from .env file
$expected_token = '';
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (strpos($line, '#') === 0 || strpos($line, '=') === false) {
            continue;
        }
        list($key, $val) = explode('=', $line, 2);
        $key = trim($key);
        $val = trim($val);
        if (preg_match('/^([\'"])(.*)\1$/', $val, $m)) {
            $val = $m[2];
        }
        if ($key === 'DB_SCHEMA_PROBE_TOKEN') {
            $expected_token = $val;
            break;
        }
    }
}

// 2. Validate Authorization Token
$received_token = $_SERVER['HTTP_X_API_TOKEN'] ?? '';
if (empty($expected_token) || !hash_equals($expected_token, $received_token)) {
    http_response_code(401);
    echo json_encode(['error' => 'UNAUTHORIZED']);
    exit;
}

// 3. Connect to Database
try {
    @include_once __DIR__ . '/config/database.php';
    if (!isset($pdo) || !$pdo instanceof PDO) {
        http_response_code(500);
        echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
        exit;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
    exit;
}

try {
    // 4. Retrieve settings configuration
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM worker_settings");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $settings = [];
    foreach ($rows as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $paused = (isset($settings['worker_paused']) && $settings['worker_paused'] === '1');
    $max_batch_size = isset($settings['max_batch_size']) ? max(1, min(10, intval($settings['max_batch_size']))) : 5;
    $stale_timeout = isset($settings['stale_timeout_seconds']) ? intval($settings['stale_timeout_seconds']) : 1800;

    if ($paused) {
        http_response_code(403);
        echo json_encode(['error' => 'WORKER_PAUSED']);
        exit;
    }

    // LAYER A skip-empty: cheap index-only count using idx_lli_claim.
    // If zero pending rows exist, skip the transaction entirely (no UPDATE,
    // no SELECT...FOR UPDATE, no follow-up scan). This eliminates the per-tick
    // heavy-work invocation when the queue is drained.
    $pendingStmt = $pdo->prepare(
        "SELECT COUNT(*) FROM lead_list_items USE INDEX (idx_lli_claim)
         WHERE enriched_at IS NULL
           AND has_website = 1
           AND worker_run_id IS NULL
           AND attempt_count < 3"
    );
    $pendingStmt->execute();
    if (intval($pendingStmt->fetchColumn()) === 0) {
        echo json_encode(['worker_run_id' => null, 'leads' => []]);
        exit;
    }

    // 5. Expire stale claims
    $pdo->prepare("
        UPDATE lead_list_items 
        SET enrichment_status = NULL, 
            worker_run_id = NULL
        WHERE enrichment_status = 'processing' 
          AND processing_started_at < NOW() - INTERVAL ? SECOND
    ")->execute([$stale_timeout]);

    // 6. Begin exclusive claim transaction
    $pdo->beginTransaction();

    // Select pending leads with FOR UPDATE row-level lock
    $selectLockStmt = $pdo->prepare("
        SELECT id 
        FROM lead_list_items
        WHERE has_website = 1
          AND (enrichment_status IS NULL OR enrichment_status = 'failed')
          AND enriched_at IS NULL
          AND (replicate_id IS NULL OR replicate_id = '')
          AND worker_run_id IS NULL
          AND attempt_count < 3
        ORDER BY id ASC
        LIMIT $max_batch_size
        FOR UPDATE
    ");
    $selectLockStmt->execute();
    $ids = $selectLockStmt->fetchAll(PDO::FETCH_COLUMN);

    if (empty($ids)) {
        $pdo->rollBack();
        echo json_encode(['worker_run_id' => null, 'leads' => []]);
        exit;
    }

    $runId = bin2hex(random_bytes(16));

    // Update statuses and set run token ownership
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $updateStmt = $pdo->prepare("
        UPDATE lead_list_items
        SET enrichment_status = 'processing',
            processing_started_at = NOW(),
            worker_run_id = ?,
            attempt_count = attempt_count + 1
        WHERE id IN ($placeholders)
    ");
    $updateStmt->execute(array_merge([$runId], $ids));

    $pdo->commit();

    // 7. Query and output final claimed leads (LAYER A: use id IN(...),
    //    not the worker_run_id re-scan). $ids is already in scope.
    $placeList = implode(',', array_fill(0, count($ids), '?'));
    $finalSelectStmt = $pdo->prepare("
        SELECT id, website, list_id
        FROM lead_list_items
        WHERE id IN ($placeList)
    ");
    $finalSelectStmt->execute($ids);
    $leads = $finalSelectStmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'worker_run_id' => $runId,
        'leads' => $leads
    ]);
    exit;

} catch (Throwable $e) {
    if ($pdo && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error' => 'CLAIM_FAILED']);
    exit;
}
