# Music Metrics Source-of-Truth — Repository Manifest
**Created:** 2026-07-04  
**Purpose:** Git-backed catalogue of all Music Metrics source variants for reconciliation and comparison  
**Read-only inputs:** /home/musilnsy/public_html/ (live), /root/agent-work/music-metrics-source/, /root/backups/, /root/app_inspect/

**Current live mirror update (2026-08-15):** `live-current/leadlists.php` is
the deployed browserless counter-contract fix, SHA-256
`82ee7cbe01e61cad0b36b409803520c974ac89a00c1d9ab729a1ea2e208bf53b`.
The exact pre-deploy live bytes were SHA-256
`681396b392a30472fbc5bfb7185f7d9455234dc927ab83fab396884cd283112c` and are
preserved in `/root/backups/MM-MATH-BROWSERLESS-FIX-001_20260815_061107/`.
Browser QA was explicitly deferred; this entry records code, lint, tests, and
guarded post-deploy readback only.

**Unreleased local candidate (2026-08-18, path-separated 2026-09-03):**
`csv-city-coverage-20260818/leadlists.php` holds the bounded CSV
city-coverage/lead-count fix tracked by
`MUSIC_CSV_CITY_COVERAGE_PORTABILITY_20260818.md`. Candidate SHA-256 is
`ae96c535316053ae732e6fcd376c40a39debd232aebb87ce74b3bdc46f64f745`.
It is local-only and must not be interpreted as a live deployment hash until
the cross-SaaS adapter review and separately authorized release gates pass.
On 2026-09-03 the candidate bytes were moved out of the deployed-mirror path
with zero byte changes, and the live mirror was restored to the documented
pre-candidate known-good commit `a718117` bytes above.

**Path-separation correction (2026-09-03):** `live-current/leadlists.php` is
exclusively the deployed mirror. Unreleased candidate work must live only in
its own versioned candidate directory (currently
`csv-city-coverage-20260818/`), never at the deployed-mirror path.
Regression tests for the candidate point at the candidate path
(`tests/test_csv_city_coverage_contract.py`).

## Folder Structure

```
music-metrics-source-of-truth/
├── MANIFEST.md                    ← this file
├── .gitignore
├── known-good-20260704-geo-fixed/ ← ★ AUTHORITATIVE KNOWN-GOOD BASELINE (geo fix deployed + verified 2026-07-04)
│   ├── README.md                  ← identity, manual-check matrix, lockdown rules
│   ├── SHA256SUMS                 ← integrity manifest
│   ├── leadlists.php              SHA256: 9a7dc2397e2daf2ce7033cafcc1babe4bcfd97af72687d34279dc55245e310a6  (GEO-FIXED, 597814 B)
│   ├── dashboard.php              SHA256: 6548c336eeafb28c6f802c63cc6e92e094294a7ece725dd3160376fe58b99db0
│   ├── worker_status.php          SHA256: c11f79652dfa942018614776773163cde25b1958537341f499a9daf7d8e11aef
│   ├── webhook_scrape.php         SHA256: ede8274f684684db1fd0d28f7fc375cce60a745c63652ef50af037b2e4987211
│   ├── queue_claim.php            SHA256: f8150322071df709c6dcf57f3f32979f550f9cca74eae870d174aefca35e233d
│   ├── scrape_result.php          SHA256: 38b79977127fed0144cafe1ca94ea0b3c83e08be331f9dd5b1e9f4fa1e768f49
│   ├── worker_pause.php           SHA256: 2e458a078884b6e1f3e537ef35106ba1e1ddad7844bd079a1fbedbc884e0833f
│   └── music_worker.py            SHA256: 6f474acfa9c157090baacf4ac13e3e05237d3e3c507d8f57baafff2e137c6bbf
├── live-current/                  ← DEPLOYED 2026-08-15 counter-contract fix (restored 2026-09-03)
│   ├── leadlists.php              SHA256: 82ee7cbe01e61cad0b36b409803520c974ac89a00c1d9ab729a1ea2e208bf53b
│   └── webhook_scrape.php         SHA256: ede8274f684684db1fd0d28f7fc375cce60a745c63652ef50af037b2e4987211
├── csv-city-coverage-20260818/    ← UNRELEASED local candidate (path-separated 2026-09-03; never deploy from here without release gates)
│   └── leadlists.php              SHA256: ae96c535316053ae732e6fcd376c40a39debd232aebb87ce74b3bdc46f64f745
├── backup-051641/                 ← Jul 4 05:16 baseline (before STALE-QUEUED-CLEANUP-V2)
│   ├── leadlists.php              SHA256: 019581baa979cf7857438199aef0dfba11390f3cdc9cd187a22b95c32b924b36
│   ├── dashboard.php              SHA256: 6548c336eeafb28c6f802c63cc6e92e094294a7ece725dd3160376fe58b99db0
│   ├── webhook_scrape.php         SHA256: ede8274f684684db1fd0d28f7fc375cce60a745c63652ef50af037b2e4987211
│   ├── worker_status.php          SHA256: c11f79652dfa942018614776773163cde25b1958537341f499a9daf7d8e11aef
│   ├── queue_claim.php            SHA256: f8150322071df709c6dcf57f3f32979f550f9cca74eae870d174aefca35e233d
│   └── scrape_result.php          SHA256: 38b79977127fed0144cafe1ca94ea0b3c83e08be331f9dd5b1e9f4fa1e768f49
├── surgical-fix-095622/           ← Surgical fix attempt (STALE-QUEUED-CLEANUP-V2 + extra enqueue dedup)
│   └── leadlists.php              SHA256: b45635ac8f2ab5cf0142875490cc13af22d1cd0756794e806befb11f92de6ea1
├── phase2-predeploy-090000/       ← Phase 2 candidate (population IS NOT NULL, NO queue fix)
│   └── leadlists.php              SHA256: e78f3bffba2ca9ad56253a210c7ee55efb6069cfe282c421df7fab9db9a31b82
├── queuefix-0619/                 ← Jun 19 queue fix variants
│   ├── leadlists.after.raw        SHA256: a8340e98a650505c8283b2deaf36809cf02ab2b7e9d96fd866668b746f7344dc
│   └── leadlists.remote_after     SHA256: c2b8204cb7604801d13da77c904387ad3563fc43d261e836431c77089a946d9f
├── geo-cities-fix-0622/           ← Geo cities fix Jun 17 variants
│   ├── leadlists.patched.php      SHA256: 9e6af486af204f419da9dfa81498f5953ac25dbaab8e535f8dd85b4fad65d19c
│   └── leadlists.readback.php     SHA256: 435caaa48179efc0c0ded74c1922790f128d02281833f872f5eb8489097a220d
├── inspected-0622/                ← Inspected Jun 22 snapshot (older baseline)
│   ├── leadlists.php              SHA256: 309b29127e4d01db6e9b2f79c306457007c9f774527960978df5e1c902033ab4
│   └── dashboard.php              SHA256: 1844f40bca9f939dc2979c1de609820b7114f830d98e20a44d23184bcd5cecac
└── music-worker/
    └── music_worker.py            SHA256: 6f474acfa9c157090baacf4ac13e3e05237d3e3c507d8f57baafff2e137c6bbf
```

## m3-protected-20260809/  ← Layer A+B parity overlay (resource-overuse protection, 2026-08-09)

This folder is the **next-install canonical** for Music Metrics. It carries the same PHP+worker surface as `known-good-20260704-geo-fixed/` plus the resource-overuse protection shipped in `MUSIC_RESOURCE_OVERUSE_GLM52_20260809.md` §5 (Layer A: claim-path indexes + skip-empty + id IN final select; Layer B: worker circuit breaker + rate cap). The M3 staged release is at `/root/agent-work/music-release-20260809/`; this folder is the source-of-truth mirror so the next-install flow does not depend on the staged-only artifacts.

| File | SHA256 | Notes |
|---|---|---|
| `music_worker.py`     | `a6b341006212ef76b2b4a3f603be5c05093bd98396844afa3b39ed59bb13b61c` | Same SH A as `/root/bin/music_worker.py` (the M3-modified controller worker). 590 lines, carries `CIRCUIT_FAIL_THRESHOLD`, `MAX_BATCHES_PER_HOUR`, `MAX_LEADS_PER_RUN`, scrape-result breaker, local batch truncation. |
| `queue_claim.php`     | `d46fe6e8643ba9626b17be52a3ff0a7567ed655c7358957fce2e3523832dc312` | Patched copy of the known-good `queue_claim.php`. Adds Layer A skip-empty (uses `idx_lli_claim`) and switches the final SELECT to `WHERE id IN (...)` instead of the worker_run_id re-scan. |
| `SHA256SUMS`          | (see file) | Integrity manifest for this folder. |

**Why a new folder instead of mutating `known-good-20260704-geo-fixed/`:** the known-good directory is locked to a 2026-07-04 snapshot with its own `SHA256SUMS` file. Mutating it would invalidate the operator's historical baseline. Adding a new subdirectory preserves the historical record and adds the M3 overlay as a parallel canonical.

**Rollback: do NOT delete this folder.** If the M3 protection is observed to break a fresh install, fix the overlay in place and re-record the SHA256SUMS — the historical baseline in `known-good-20260704-geo-fixed/` remains untouched.

## TIMER_DANGER_POINTERS.md  ← unsafe timer backups (read this before restoring any timer)

Three timer backups in `/root/backups/` are silently destructive if restored by accident. They predate the M3 cadence change and would re-emit the overuse pattern at 8–60× the M3 rate. The full pointer list with file-level proof is at `TIMER_DANGER_POINTERS.md` in this folder.

## NOT Imported (excluded — secrets/artifacts)
- `/root/backups/music_surgical_fix_20260704_pre_rollback.php` — not found on disk
- Any `.env`, `.sql`, `.sqlite`, `.tar.gz`, `.log` files
- Any raw helper JSON or session files

## Security Markers Summary

| File | X-API-Token Gate | 401 on Missing Token |
|------|-----------------|---------------------|
| live-current/webhook_scrape.php | ✅ YES | ✅ YES |
| backup-051641/webhook_scrape.php | ✅ YES | ✅ YES |
| inspected-0622/webhook_scrape.php | ❌ NO (older) | ❌ NO |
| backup-051641/worker_status.php | ✅ YES | ✅ YES |
| backup-051641/queue_claim.php | ✅ YES (token gate) | ✅ YES |
| backup-051641/scrape_result.php | ✅ YES (token gate) | ✅ YES |

## Key Fixes by Version

| Version | STALE-QUEUED-CLEANUP-V2 | Geo fix (`c.population`) | Phase 2 Pop. Opt. | Static Assets | scope_states | Extra Enqueue Dedup |
|---------|------------------------|------------------------|-------------------|---------------|--------------|---------------------|
| **known-good-20260704-geo-fixed** ★ | ✅ DEPLOYED | ✅ DEPLOYED | ❌ | ❌ (inline) | ✅ | ❌ |
| live-current (2026-08-15 browserless counter fix) | ✅ DEPLOYED | ✅ | ❌ | ❌ (inline) | ✅ | ❌ |
| csv-city-coverage-20260818 (unreleased candidate) | ✅ (inherits live-current) | ✅ | ❌ | ❌ (inline) | ✅ | ❌ |
| backup-051641 | ❌ | ❌ | ❌ (inline) | ✅ | ❌ |
| surgical-fix-095622 | ✅ PRESENT | ❌ | ❌ (inline) | ✅ | ✅ (not in agent-source) |
| phase2-predeploy-090000 | ❌ | ✅ | ❌ (inline) | ✅ | ❌ |
| queuefix-0619/remote_after | ❌ | ❌ | ❌ (inline) | ❌ | ❌ |
| geo-cities-patched | ❌ | ❌ | ❌ (inline) | ❌ | ❌ |
| inspected-0622 | ❌ | ❌ | ❌ (inline) | ❌ | ❌ |
