<?php
/**
 * Music Metrics — bootstrap fastpath unit test (perf/request-fastpath-20260925)
 * Run: php tests/php/test-bootstrap-fastpath.php
 * Exit 0 = PASS, 1 = FAIL.
 */
$src = file_get_contents(__DIR__ . '/../../live-current/leadlists.php');
$fail = 0;
function check(bool $cond, string $msg): void {
    global $fail;
    echo ($cond ? "PASS: " : "FAIL: ") . $msg . PHP_EOL;
    if (!$cond) $fail++;
}

// 1) Helpers marker segment exists and evals
check(strpos($src, '// === MM-BOOTSTRAP-FASTPATH:HELPERS ===') !== false, 'helpers marker present');
$m = preg_match('/\/\/ === MM-BOOTSTRAP-FASTPATH:HELPERS ===(.*?)\/\/ === MM-BOOTSTRAP-FASTPATH:HELPERS-END ===/s', $src, $mm);
check($m === 1, 'helpers segment extractable');
if ($m === 1) {
    eval($mm[1]);
    check(function_exists('mm_bootstrap_needed'), 'mm_bootstrap_needed defined');
    check(function_exists('mm_bootstrap_flag_path'), 'mm_bootstrap_flag_path defined');
}

if (function_exists('mm_bootstrap_needed')) {
    $tmpFlagDir = sys_get_temp_dir() . '/mm-bfp-test-' . getmypid();
    @mkdir($tmpFlagDir, 0777, true);

    // 2) No flag -> bootstrap needed
    check(mm_bootstrap_needed('vTEST', $tmpFlagDir) === true, 'needed=true when flag absent');

    // 3) Flag written with same version -> not needed
    file_put_contents($tmpFlagDir . '/mm-bootstrap.flag', 'vTEST');
    check(mm_bootstrap_needed('vTEST', $tmpFlagDir) === false, 'needed=false when flag matches version');

    // 4) Version bump invalidates flag
    check(mm_bootstrap_needed('vTEST2', $tmpFlagDir) === true, 'needed=true on version bump');

    // 5) Unwritable/missing dir -> fail-safe to needed=true
    check(mm_bootstrap_needed('vTEST', '/nonexistent-dir/definitely-missing') === true, 'needed=true when flag dir missing (fail-safe)');

    // 6) Corrupt/empty flag treated as needed
    file_put_contents($tmpFlagDir . '/mm-bootstrap.flag', '');
    check(mm_bootstrap_needed('vTEST', $tmpFlagDir) === true, 'needed=true on empty flag');

    @unlink($tmpFlagDir . '/mm-bootstrap.flag');
    @rmdir($tmpFlagDir);
}

// 7) Structural: guard wraps section, flag written on bootstrap completion
check(strpos($src, 'if (!$mmBootstrapSkip) {') !== false, 'guard opens bootstrap section');
check(strpos($src, 'mm_bootstrap_flag_path(), MM_BOOTSTRAP_VERSION') !== false, 'flag written after bootstrap run');
check(strpos($src, 'MM-BOOTSTRAP-FASTPATH:SECTION') !== false, 'section markers present');

// 8) computeLeadScore must be defined BEFORE the guard (always available)
$guardPos = strpos($src, 'if (!$mmBootstrapSkip) {');
$scorePos = strpos($src, 'function computeLeadScore');
check($guardPos !== false && $scorePos !== false && $scorePos < $guardPos, 'computeLeadScore relocated above guard');

exit($fail === 0 ? 0 : 1);
