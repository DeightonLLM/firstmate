#!/usr/bin/env python3
"""Local regression tests for Music Metrics CSV city coverage v1.1.

These tests are deliberately database-free.  They lock the source contract and
exercise the minimum round-trip invariant: a lead row plus a zero-result
coverage row must come back as one lead, two covered cities, and preserved
scraped/current counts.
"""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "csv-city-coverage-20260818/leadlists.php"


def round_trip(rows):
    leads = [row for row in rows if row["Record Type"] == "lead"]
    coverage = {}
    for row in rows:
        key = (row["Searched State"].strip().lower(), row["Searched City"].strip().lower())
        if not key[1]:
            continue
        item = coverage.setdefault(key, {"scraped": 0, "current": 0})
        item["scraped"] = max(item["scraped"], int(row.get("Scraped Lead Count", 0) or 0))
        item["current"] = max(item["current"], int(row.get("City Lead Count", 0) or 0))
    return leads, coverage


def main():
    source = SOURCE.read_text()

    required_literals = [
        "CSV contract v1.1",
        "'Record Type'",
        "'Searched City'",
        "'Searched State'",
        "'City Lead Count'",
        "'Scraped Lead Count'",
        "if ($recordType === 'coverage') continue;",
        "INSERT INTO lead_list_searches",
        "UNION",
    ]
    for literal in required_literals:
        assert literal in source, f"missing CSV coverage contract marker: {literal}"

    assert "'State', 'State Name', 'Region', 'Province', 'Country'" not in source
    assert "COALESCE(stats.lead_count, 0) as lead_count" in source
    assert "COUNT(*) as cities_searched" in source

    rows = [
        {
            "Record Type": "lead",
            "Searched State": "Illinois",
            "Searched City": "Springfield",
            "City Lead Count": "1",
            "Scraped Lead Count": "1",
        },
        {
            "Record Type": "coverage",
            "Searched State": "Illinois",
            "Searched City": "Springfield",
            "City Lead Count": "1",
            "Scraped Lead Count": "1",
        },
        {
            "Record Type": "coverage",
            "Searched State": "Illinois",
            "Searched City": "Peoria",
            "City Lead Count": "0",
            "Scraped Lead Count": "0",
        },
    ]
    leads, coverage = round_trip(rows)
    assert len(leads) == 1
    assert len(coverage) == 2
    assert coverage[("illinois", "springfield")] == {"scraped": 1, "current": 1}
    assert coverage[("illinois", "peoria")] == {"scraped": 0, "current": 0}

    print("CSV-CITY T1 PASS: v1.1 lead and coverage records are source-backed")
    print("CSV-CITY T2 PASS: zero-result scraped city survives round-trip")
    print("CSV-CITY T3 PASS: current and scraped lead counts remain distinct")


if __name__ == "__main__":
    main()
