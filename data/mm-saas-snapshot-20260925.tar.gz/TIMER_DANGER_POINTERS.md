# Music Metrics — Timer Danger Pointers

**Date:** 2026-08-09 UTC
**Status:** Parity-overlay artifact (paired with `m3-protected-20260809/`).
**Purpose:** Capture the three timer backups that are silently destructive if restored by accident. The live timer (`/etc/systemd/system/music-enrichment-drip.timer`) was modified by the M3 lane to `OnUnitActiveSec=20m` + `RandomizedDelaySec=120` and is the **only** safe cadence. Any of the three backups below will re-emit the overuse pattern at 8–60× the M3 rate.

## Stop conditions satisfied

- The backups are **not** modified, renamed, or deleted in this lane. The immutable historical record is preserved.
- The mutation boundary is limited to: this pointer file, the `m3-protected-20260809/` overlay, and the installer index block. No backup file is touched.

## The three unsafe timers

| # | Path | OnUnitActiveSec | RandomizedDelaySec | OnBootSec | Persistent | Risk vs M3 (20m+jitter) |
|---|---|---|---|---|---|---|
| 1 | `/root/backups/hardening_20260703/music-enrichment-drip.timer.orig` | **1m** | — | 1m | ❌ | **60× faster** than M3; no Persistence means a missed fire is never retried. Restoring this silently re-emits the post-suspension 403 storm at 60 ticks/hour. |
| 2 | `/root/backups/music_timer_20260530_timer` | **120s (2m)** | — | 60s | ✅ | 10× faster than M3. Was the pre-M3 conventional cadence. |
| 3 | `/root/backups/music_timer_20260530_timer_final` | **150s (2.5m)** | — | 60s | ✅ | 8× faster than M3. Variant of #2. |

`grep -E "OnUnitActiveSec|OnBootSec" <path>` confirms the values above.

## Why this pointer exists

The previous (`MUSIC_METRICS_VERSION_PARITY_20260809.md`) audit classified these three files as having the smallest cadence of any version. If a future operator runs `cp /root/backups/music_timer_20260530_timer /etc/systemd/system/music-enrichment-drip.timer` to undo a change, the M3 protections are immediately overwhelmed by request rate. The circuit breaker has no time to interpose before the 403 / 429 / 5xx error budget is exhausted.

## Recommended next step (out of this lane's scope)

A separate operator-authorized lane should rename each timer backup with a `.DANGER-1m` / `.DANGER-2m` / `.DANGER-2.5m` suffix so an accidental `cp *` cannot restore them by typo. This lane does not perform the rename because the backups are immutable historical records.

## Cross-check pointer

The M3-modified live timer is at `/etc/systemd/system/music-enrichment-drip.timer` (20m + 120s jitter). Its SH A is identical to the M3 lane's earlier capture; the `m3-protected-20260809/` overlay does NOT include a timer file because the timer is a runtime artifact generated on the enrichment host, not a source-of-truth file. The overlay's `MANIFEST.md` addendum points here for any future restore.
