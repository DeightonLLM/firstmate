<?php
/**
 * Worker Status Endpoint - Read-Only
 * Exposes configuration and pause states safely without leaking credentials, paths, or errors.
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// ---------------------------------------------------------------------------
// Auth gate (audit S-C2, 2026-07-04):
// Status JSON reveals internal operational state (worker_paused, batch size,
// stale timeout). Require the same X-API-Token used by the other worker
// endpoints (token source: DB_SCHEMA_PROBE_TOKEN in .env). Anonymous requests
// must be rejected with a minimal body, no internal details.
// ---------------------------------------------------------------------------
$expected_token = '';
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (strpos($line, '#') === 0 || strpos($line, '=') === false) continue;
        list($key, $val) = explode('=', $line, 2);
        $key = trim($key);
        $val = trim($val);
        if (preg_match('/^([\'"])(.*)\1$/', $val, $m)) $val = $m[2];
        if ($key === 'DB_SCHEMA_PROBE_TOKEN') { $expected_token = $val; break; }
    }
}
$h = $_SERVER['HTTP_X_API_TOKEN'] ?? '';
$received_token = $h !== '' ? $h : '';
if (empty($expected_token) || !hash_equals($expected_token, $received_token)) {
    http_response_code(401);
    echo json_encode(['error' => 'UNAUTHORIZED']);
    exit;
}

try {
    @include_once __DIR__ . '/config/database.php';
    if (!isset($pdo) || !$pdo instanceof PDO) {
        http_response_code(500);
        echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
        exit;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM worker_settings");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $settings = [];
    foreach ($rows as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $paused = (isset($settings['worker_paused']) && $settings['worker_paused'] === '1');
    $max_batch_size = isset($settings['max_batch_size']) ? intval($settings['max_batch_size']) : 5;
    $stale_timeout = isset($settings['stale_timeout_seconds']) ? intval($settings['stale_timeout_seconds']) : 1800;
    $reason = $settings['pause_reason'] ?? '';

    echo json_encode([
        'status' => $paused ? 'paused' : 'running',
        'worker_paused' => $paused,
        'pause_reason' => $reason,
        'max_batch_size' => $max_batch_size,
        'stale_timeout_seconds' => $stale_timeout
    ]);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'INTERNAL_ERROR']);
    exit;
}
