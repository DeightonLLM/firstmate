<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'dashboard-error.log');

if (!file_exists('includes/auth.php')) {
    die('includes/auth.php is missing');
}

require_once 'includes/auth.php';
require_once 'includes/theme_bootstrap.php';

try {
    $pdo->query('SELECT 1');
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    die("Database connection error. Please check the logs.");
}

try {
    $tableExists = $pdo->query("SHOW TABLES LIKE 'api_calls'")->rowCount() > 0;
    
    if (!$tableExists) {
        $pdo->exec("CREATE TABLE api_calls (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            credits_used INT NOT NULL,
            scraper_model VARCHAR(50) NOT NULL,
            url VARCHAR(2048) NOT NULL,
            input_params JSON,
            status VARCHAR(50),
            error_message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_date (user_id, created_at)
        )");
        error_log("Created api_calls table successfully");
    }
} catch (PDOException $e) {
    error_log("Table creation error: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'subscription_plan'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE users ADD COLUMN subscription_plan VARCHAR(50) DEFAULT 'none'");
        error_log("Added subscription_plan column successfully");
    }
} catch (PDOException $e) {
    error_log("Error checking/adding subscription_plan column: " . $e->getMessage());
}

try {
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'shared_for_credits'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE users ADD COLUMN shared_for_credits TINYINT DEFAULT 0");
    }
} catch (PDOException $e) {
    error_log("Error checking/adding shared_for_credits column: " . $e->getMessage());
}

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$userName = $_SESSION['user_name'] ?? 'User';
$userId = $_SESSION['user_id'];
$isAdminViewing = isset($_SESSION['admin_original_id']);

// Release session lock before read-only work so parallel tabs do not block.
session_write_close();

try {
    $stmt = $pdo->prepare("SELECT credits, subscription_plan, shared_for_credits, is_admin FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    $userCredits = $userData['credits'] ?? 0;
    $userPlan = $userData['subscription_plan'] ?? 'none';
    $hasShared = $userData['shared_for_credits'] ?? 0;
    $isAdmin = !empty($userData['is_admin']);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $userCredits = 0;
    $userPlan = 'none';
    $hasShared = 0;
}

$current_section = isset($_GET['section']) ? $_GET['section'] : 'lead_lists';
$hd2Categories = [
    'Healthcare' => ['Doctors','Medical Clinics','Dentists','Orthodontists','Oral Surgeons','Plastic Surgeons','Dermatologists','Optometrists','Chiropractors','Physical Therapists','Pharmacies','Personal Trainers','Senior Living'],
    'Home Services' => ['HVAC','Plumbing','Electrical','Roofing','Landscaping','Pest Control','Solar','Pool Services','Cleaning Services','General Contractors'],
    'Automotive' => ['New Car Dealers','Used Car Dealers','Auto Repair','Quick Lube','Tire Shops','Auto Body','Fleet Services','Car Stereo','Auto Detailers','Towing'],
    'Professional Services' => ['Law Firms','Accounting','Recruiters','Marketing','SEO','Insurance Agencies','Mortgage Brokers','Financial Advisors','IT Services','Consultants'],
    'Consumer & Retail' => ['Restaurants','Hotels','Cafes','Bars','Nightclubs','Gyms','Tattoo Studios','Salons','Smoke Shops','CBD Stores','Cannabis Businesses'],
    'Government' => ['Federal','State','County','City','Police','Fire','Utilities','Public Works','Building Departments','Transportation Authorities'],
    'Education' => ['Universities','Colleges','Community Colleges','Public Schools','Private Schools','Charter Schools','Trade Schools','School Districts'],
    'Religious Organizations' => ['Churches','Catholic Parishes','Ministries','Synagogues','Mosques','Temples','Faith Schools','Religious Foundations'],
    'Nonprofits' => ['Charities','NGOs','Foundations','Food Banks','Community Organizations','Homeless Shelters','Animal Rescues'],
    'Manufacturing & Industrial' => ['Manufacturers','Factories','Fabricators','Machine Shops','Industrial Suppliers','Welding','Packaging','Electronics'],
    'Logistics & Transportation' => ['Trucking','Warehousing','Freight Brokers','Logistics Providers','Distribution Centers','Ports'],
    'Real Estate' => ['Realtors','Property Managers','Commercial Brokers','Developers','Investors','HOA Management'],
    'Agriculture & Cultivation' => ['Farms','Nurseries','Greenhouses','Hemp','Cannabis Cultivators','Seed Companies'],
    'Financial Services' => ['Banks','Credit Unions','Investment Firms','VC Firms','PE Firms','Wealth Managers'],
    'Technology' => ['SaaS','AI Companies','Software Companies','MSPs','Cybersecurity','Data Centers'],
    'Media & Publishing' => ['Radio','Newspapers','Podcasts','Publishers','Digital Media','PR Firms'],
    'Entertainment' => ['Music Venues','Event Promoters','Festivals','Theaters','Record Labels'],
    'Travel & Tourism' => ['Travel Agencies','Tour Operators','Airlines','Cruise Operators','Resorts'],
    'Construction & Infrastructure' => ['Civil Engineering','Infrastructure','Heavy Equipment','Commercial Builders'],
    'Energy' => ['Oil & Gas','Renewables','Solar Developers','Wind Energy','Power Generation'],
    'Telecommunications' => ['ISPs','Wireless Providers','Fiber Providers','VoIP','Satellite Communications'],
    'Veterinary' => ['Veterinary Clinics','Animal Hospitals','Pet Grooming','Pet Boarding'],
    'Wellness' => ['Med Spas','Wellness Clinics','Massage Therapy','Nutritionists','Mental Health'],
    'Sports & Recreation' => ['Sports Clubs','Fitness Studios','Recreation Centers','Outdoor Recreation'],
    'Security' => ['Security Companies','Alarm Companies','Private Security','Cybersecurity Services'],
    'Insurance Carriers' => ['Health Insurance','Auto Insurance','Property Insurance','Commercial Insurance'],
    'Maritime' => ['Marinas','Boat Dealers','Shipyards','Marine Services'],
    'Mining' => ['Mining Companies','Quarries','Mineral Exploration','Mining Services'],
    'Waste Management' => ['Waste Haulers','Recycling Centers','Dumpster Rental','Environmental Services'],
    'Wholesale' => ['Wholesalers','Distributors','Importers','Exporters'],
    'Staffing' => ['Staffing Agencies','Temp Agencies','Executive Search','HR Services'],
    'Gambling' => ['Casinos','Sports Betting','Gaming Operators','Lottery Services'],
    'Regulated Industries' => ['Compliance Services','Licensed Operators','Regulated Retail','Specialty Permits'],
];
?>

<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Dashboard</title>
    <link rel="icon" type="image/svg+xml" href="<?php echo APP_LOGO; ?>?v=20260606">
    <link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            <?php
            $primary = defined('BRAND_COLOR') ? BRAND_COLOR : '#00388F';
            $secondary = '#2a8a87';
            $activeNav = 'rgba(var(--accent-rgb), 0.1)';
            ?>
            --bg-color: #f2f2f7;
            --accent-primary: <?php echo $primary; ?>;
            --accent-secondary: <?php echo $secondary; ?>;
            --text-main: #1c1c1e;
            --text-muted: #8e8e93;
            --sidebar-bg: #ffffff;
            --sidebar-border: rgba(0, 0, 0, 0.06);
            --glass-bg: #ffffff;
            --plan-badge-bg: #ffffff;
            --nav-hover-bg: rgba(0, 0, 0, 0.03);
            --nav-active-bg: <?php echo $activeNav; ?>;
            --scrollbar-thumb: rgba(0,0,0,0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        body {
            display: flex;
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', 'Inter', 'Helvetica Neue', sans-serif;
            height: 100vh;
            overflow: hidden;
        }

        .menu-toggle {
            position: fixed;
            top: 1rem;
            left: 1rem;
            font-size: 1.25rem;
            cursor: pointer;
            z-index: 1001;
            color: var(--text-main);
            display: none;
            background: var(--sidebar-bg);
            padding: 10px;
            border-radius: 12px;
            border: 1px solid var(--sidebar-border);
        }

        .sidebar {
            width: 260px;
            height: 100vh;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--sidebar-border);
            padding: 12px 16px 24px 16px;
            position: fixed;
            transition: transform 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 12px;
            padding: 0 8px;
            font-weight: 700;
            font-size: 15px;
            color: var(--text-main);
            letter-spacing: -0.02em;
            text-decoration: none;
        }

        .logo img, .app-logo-img, .logo .theme-logo, .logo .theme-logo__image {
            height: 52px !important;
            width: auto !important;
            max-width: none !important;
            border-radius: 8px;
            object-fit: contain;
            flex-shrink: 0;
        }

        .logo .theme-logo-lockup {
            gap: 16px !important;
        }

        .logo .theme-logo-wordmark {
            font-size: 20px !important;
        }

        .nav-links {
            list-style: none;
            flex: 1;
            overflow-y: auto;
        }

        .nav-links::-webkit-scrollbar { width: 4px; }
        .nav-links::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.1); border-radius: 4px; }

        .nav-item {
            margin-bottom: 2px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 10px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 14px;
            font-weight: 500;
        }

        .nav-link:hover {
            background: var(--nav-hover-bg);
            color: var(--text-main);
        }

        .nav-link.active {
            background: var(--nav-active-bg);
            color: var(--accent-primary);
        }

        .nav-link.active i {
            color: var(--accent-primary);
        }

        .nav-link i {
            width: 24px;
            text-align: center;
            font-size: 16px;
            color: var(--text-muted);
            transition: color 0.2s ease;
        }

        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 0;
            width: calc(100% - 260px);
            height: 100vh;
            position: relative;
            overflow: hidden;
            background: var(--bg-color);
        }

        .content-section {
            display: none;
            height: 100%;
        }

        .content-section.active {
            display: block;
            height: 100%;
            background: var(--bg-color);
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .submenu {
            list-style: none;
            margin-left: 0;
            padding-left: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, opacity 0.3s ease;
            max-height: 0;
            opacity: 0;
        }

        .submenu.active {
            max-height: 500px;
            opacity: 1;
            margin-top: 2px;
            margin-bottom: 8px;
        }

        .submenu-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px 8px 42px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 13px;
            border-radius: 8px;
        }

        .submenu-link:hover {
            color: var(--text-main);
            background: var(--nav-hover-bg);
        }

        .submenu-link.active {
            color: var(--accent-primary);
            background: var(--nav-active-bg);
        }

        .submenu-link i {
             width: 16px;
             text-align: center;
        }

        .category-nav {
            display: none;
            list-style: none;
            padding: 6px 0 8px 18px;
            margin: 0;
        }

        .nav-item.categories-open .category-nav { display: block; }

        .category-group-btn,
        .category-link {
            width: 100%;
            border: 0;
            background: transparent;
            color: var(--text-muted);
            font: inherit;
            text-align: left;
            cursor: pointer;
        }

        .category-group-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 10px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
        }

        .category-group-btn:hover,
        .category-link:hover,
        .category-link.active {
            color: var(--accent-primary);
            background: var(--nav-active-bg);
        }

        .category-group-btn .fa-chevron-right {
            margin-left: auto;
            font-size: 11px;
            transition: transform 0.18s ease;
        }

        .category-group.open .category-group-btn .fa-chevron-right {
            transform: rotate(90deg);
        }

        .category-items {
            display: none;
            padding: 2px 0 4px 24px;
        }

        .category-group.open .category-items { display: block; }

        .category-link {
            display: block;
            padding: 7px 10px;
            border-radius: 8px;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .nav-link .fa-chevron-down {
            margin-left: auto;
            font-size: 0.7rem;
            transition: transform 0.3s ease;
        }

        .nav-link.expanded .fa-chevron-down {
            transform: rotate(180deg);
        }

        .plan-badge {
            position: fixed;
            bottom: 16px;
            left: 16px;
            width: 228px;
            background: var(--plan-badge-bg);
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--sidebar-border);
            z-index: 1001;
        }

        .plan-badge-label {
            font-size: 11px;
            color: var(--text-muted);
            margin-bottom: 2px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }

        .plan-badge-value {
            font-size: 15px;
            color: var(--text-main);
            font-weight: 600;
            text-transform: capitalize;
        }

        #loading {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(245, 245, 247, 0.95);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }

        .spinner {
            width: 36px;
            height: 36px;
            border: 3px solid rgba(0, 0, 0, 0.08);
            border-top: 3px solid var(--accent-primary);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        iframe {
            width: 100%;
            height: 100%;
            border: none;
            background: var(--bg-color);
        }

        [id$="-content"] {
            height: 100%;
        }

        .credits-pill {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 8px;
            background: rgba(var(--accent-rgb), 0.08);
            color: var(--accent-primary);
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            margin-left: auto;
        }

        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; width: 100%; }
            .plan-badge { display: none; }
            /* Responsive: ensure nav icons are visible and tappable at narrow widths */
            .nav-link { justify-content: flex-start; padding: 12px 10px; }
            .nav-link span { display: none; }
            .nav-link i { font-size: 20px; width: 24px; margin: 0; flex-shrink: 0; }
            .credits-pill { display: none; }
            /* Theme-toggle button: match nav-link behavior */
            .nav-link[data-theme-toggle] { justify-content: flex-start; padding: 12px 10px; }
            .nav-link[data-theme-toggle] i { font-size: 20px; width: 24px; margin: 0; flex-shrink: 0; }
        }

        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--scrollbar-thumb); border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--text-muted); }

        html[data-theme="dark"] {
            --bg-color: #0b1220;
            --text-main: #f3f6fb;
            --text-muted: #aab3c2;
            --sidebar-bg: rgba(10, 15, 24, 0.98);
            --sidebar-border: rgba(255, 255, 255, 0.08);
            --glass-bg: rgba(17, 24, 39, 0.85);
            --plan-badge-bg: rgba(17, 24, 39, 0.95);
            --nav-hover-bg: rgba(255, 255, 255, 0.05);
            --nav-active-bg: <?php echo 'rgba(var(--accent-rgb), 0.14)'; ?>;
            --scrollbar-thumb: rgba(255, 255, 255, 0.12);
        }

        html[data-theme="dark"] .sidebar,
        html[data-theme="dark"] .menu-toggle {
            background: var(--sidebar-bg);
            border-color: var(--sidebar-border);
            box-shadow: 14px 0 36px rgba(0, 0, 0, 0.28);
        }

        html[data-theme="dark"] .plan-badge {
            background: var(--plan-badge-bg);
            border-color: var(--sidebar-border);
            box-shadow: 0 14px 34px rgba(0, 0, 0, 0.30);
        }

        html[data-theme="dark"] .logo,
        html[data-theme="dark"] .plan-badge-value {
            color: var(--text-main);
        }

        html[data-theme="dark"] .nav-link,
        html[data-theme="dark"] .nav-link i,
        html[data-theme="dark"] .submenu-link,
        html[data-theme="dark"] .plan-badge-label {
            color: var(--text-muted);
        }

        html[data-theme="dark"] .nav-link:hover,
        html[data-theme="dark"] .submenu-link:hover {
            color: var(--text-main);
        }

        /* Theme toggle icon visibility - match nav-link icon sizing */
        .nav-link[data-theme-toggle] i {
            width: 24px;
            text-align: center;
            font-size: 16px;
            color: var(--text-muted);
            transition: color 0.2s ease;
        }
        .nav-link[data-theme-toggle]:hover i {
            color: var(--text-main);
        }
        .theme-toggle-icon-light { display: none; }
        html[data-theme="dark"] .theme-toggle-icon-dark { display: none; }
        html[data-theme="dark"] .theme-toggle-icon-light { display: inline-block; }
        .nav-link[data-theme-toggle] { display: flex; align-items: center; gap: 10px; }
        .nav-link[data-theme-toggle] [data-theme-label] {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-muted);
        }
    </style>
    <?php theme_bootstrap_head(); ?>
</head>
<body>
    <?php if ($isAdminViewing): ?>
    <div id="adminBanner" style="position:fixed;top:0;left:0;right:0;z-index:99999;background:linear-gradient(135deg,#FF3B30,#FF2D55);color:#fff;padding:8px 20px;font-size:13px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:12px;font-family:'Inter',sans-serif;">
        <i class="fas fa-user-secret"></i> Viewing as <?php echo htmlspecialchars($userName); ?>
        <button onclick="returnToAdmin()" style="background:rgba(255,255,255,0.2);color:#fff;border:none;padding:5px 14px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;">Return to Admin</button>
    </div>
    <script>
    async function returnToAdmin() {
        const res = await fetch('admin.php', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'return_to_admin'}) });
        const data = await res.json();
        if (data.success) window.location.href = 'admin.php';
    }
    document.body.style.paddingTop = '40px';
    </script>
    <?php endif; ?>
    <div class="plan-badge">
        <div class="plan-badge-label">Current Plan</div>
        <div class="plan-badge-value"><?php echo $userPlan === 'none' ? 'No Plan' : ucfirst($userPlan); ?></div>
    </div>

    <div class="menu-toggle">
        <i class="fas fa-bars"></i>
    </div>

    <div class="sidebar">
        <a href="index.php" class="logo" title="Home" aria-label="Home">
            <?php echo themeLogoLockup('sidebar'); ?>
        </a>
        <ul class="nav-links">
            <li class="nav-item" id="leadListsNavItem">
                <a href="?section=lead_lists" class="nav-link <?php echo $current_section === 'lead_lists' ? 'active' : ''; ?>" data-section="lead_lists" id="leadListsNavLink">
                    <i class="fas fa-folder-open"></i>
                    Lead Lists
                    <i class="fas fa-chevron-down"></i>
                </a>
                <ul class="category-nav" id="leadCategoryNav">
                    <?php foreach ($hd2Categories as $group => $categories): ?>
                    <li class="category-group">
                        <button type="button" class="category-group-btn">
                            <i class="fas fa-layer-group"></i>
                            <span><?php echo htmlspecialchars($group); ?></span>
                            <i class="fas fa-chevron-right"></i>
                        </button>
                        <div class="category-items">
                            <?php foreach ($categories as $category): ?>
                            <button type="button" class="category-link" data-group="<?php echo htmlspecialchars($group); ?>" data-category="<?php echo htmlspecialchars($category); ?>" title="<?php echo htmlspecialchars($category); ?>"><?php echo htmlspecialchars($category); ?></button>
                            <?php endforeach; ?>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </li>
            <li class="nav-item">
                <a href="?section=api_dashboard" class="nav-link <?php echo $current_section === 'api_dashboard' ? 'active' : ''; ?>" data-section="api_dashboard">
                    <i class="fas fa-solid fa-plug"></i>
                    API Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="?section=section5" class="nav-link <?php echo $current_section === 'section5' ? 'active' : ''; ?>" data-section="section5">
                    <i class="fas fa-credit-card"></i>
                    Plans <span class="credits-pill"><?php echo number_format($userCredits); ?></span>
                </a>
            </li>
            <?php if ($isAdmin): ?>
            <li class="nav-item">
                <a href="admin.php" class="nav-link">
                    <i class="fas fa-user-shield"></i>
                    Admin Panel
                </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
                <button type="button" class="nav-link" data-theme-toggle style="width:100%;border:none;background:none;text-align:left;font:inherit;cursor:pointer;" aria-label="Toggle color theme">
                    <i class="fa-solid fa-moon theme-toggle-icon-dark" aria-hidden="true"></i>
                    <i class="fa-solid fa-sun theme-toggle-icon-light" aria-hidden="true"></i>
                    <span data-theme-label>Dark mode</span>
                </button>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link" id="logoutBtn">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div id="lead_lists" class="content-section <?php echo $current_section === 'lead_lists' ? 'active' : ''; ?>">
            <div id="lead_lists-content"></div>
        </div>
        <div id="api_dashboard" class="content-section <?php echo $current_section === 'api_dashboard' ? 'active' : ''; ?>">
            <div id="api_dashboard-content"></div>
        </div>
        <div id="section5" class="content-section <?php echo $current_section === 'section5' ? 'active' : ''; ?>">
            <div id="section5-content"></div>
        </div>
    </div>

    <div id="loading">
        <div class="spinner"></div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navLinks = document.querySelectorAll('.nav-link');
            const contentSections = document.querySelectorAll('.content-section');
            const loading = document.getElementById('loading');
            const menuToggle = document.querySelector('.menu-toggle');
            const sidebar = document.querySelector('.sidebar');
            const logoutBtn = document.getElementById('logoutBtn');
            const themeRoot = document.documentElement;
            const leadListsNavItem = document.getElementById('leadListsNavItem');
            const initialCategoryGroup = <?php echo json_encode($_GET['category_group'] ?? ''); ?>;
            const initialCategory = <?php echo json_encode($_GET['category'] ?? ''); ?>;
            let activeCategoryGroup = initialCategoryGroup;
            let activeCategory = initialCategory;
            
            const urls = {
                'lead_lists': 'leadlists.php',
                'api_dashboard': 'api_dashboard.php',
                'section5': 'pricing.php?embed=1'
            };

            const currentSection = '<?php echo $current_section; ?>';
            loadContent(currentSection);
            setActiveCategory(activeCategoryGroup, activeCategory, false);

            function syncEmbeddedTheme() {
                const theme = themeRoot.dataset.theme || (window.ThemeBootstrap ? window.ThemeBootstrap.getTheme() : 'light');
                const bgColor = theme === 'dark' ? '#0b1220' : '#ffffff';
                document.querySelectorAll('.content-section iframe').forEach(frame => {
                    try {
                        frame.style.background = bgColor;
                        if (frame.contentWindow && frame.contentWindow.ThemeBootstrap) {
                            frame.contentWindow.ThemeBootstrap.setTheme(theme);
                        } else if (frame.contentDocument) {
                            frame.contentDocument.documentElement.dataset.theme = theme;
                            frame.contentDocument.documentElement.style.colorScheme = theme;
                            frame.contentDocument.body.style.background = bgColor;
                            frame.contentDocument.documentElement.style.background = bgColor;
                        }
                    } catch (error) {}
                });
            }

            new MutationObserver(syncEmbeddedTheme).observe(themeRoot, { attributes: true, attributeFilter: ['data-theme'] });
            window.addEventListener('storage', (event) => {
                if (event.key === 'lead-gen-saas-theme' && window.ThemeBootstrap && event.newValue) {
                    window.ThemeBootstrap.setTheme(event.newValue);
                    syncEmbeddedTheme();
                }
            });

            navLinks.forEach(link => {
                if (!link.id || link.id !== 'logoutBtn') {
                    link.addEventListener('click', function(e) {
                        const sectionId = this.getAttribute('data-section');
                        if (!sectionId) return;
                        e.preventDefault();
                        if (sectionId === 'lead_lists') {
                            leadListsNavItem?.classList.toggle('categories-open');
                            this.classList.toggle('expanded');
                            setActiveCategory('', '', true);
                            return;
                        }
                        
                        navLinks.forEach(l => l.classList.remove('active'));
                        contentSections.forEach(s => s.classList.remove('active'));
                        
                        this.classList.add('active');
                        document.getElementById(sectionId).classList.add('active');
                        
                        window.history.pushState({}, '', `?section=${sectionId}`);
                        
                        loadContent(sectionId);
                    });
                }
            });

            document.querySelectorAll('.category-group-btn').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    this.closest('.category-group')?.classList.toggle('open');
                });
            });

            document.querySelectorAll('.category-link').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    setActiveCategory(this.dataset.group || '', this.dataset.category || '', true);
                    if (window.innerWidth <= 768) sidebar.classList.remove('active');
                });
            });

            logoutBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                try {
                    const response = await fetch('logout.php');
                    const data = await response.json();
                    if (data.success) {
                        window.location.href = 'login.php';
                    }
                } catch (error) {
                    console.error('Logout error:', error);
                }
            });

            menuToggle.addEventListener('click', () => {
                sidebar.classList.toggle('active');
            });

            async function loadContent(sectionId) {
                try {
                    loading.style.display = 'flex';
                    const contentDiv = document.getElementById(`${sectionId}-content`);
                    if (contentDiv) {
                        const existingFrame = contentDiv.querySelector('iframe');
                        let src = sectionId === 'lead_lists' ? 'leadlists.php' : urls[sectionId];
                        if (sectionId === 'lead_lists' && activeCategoryGroup && activeCategory) {
                            const params = new URLSearchParams({
                                category_group: activeCategoryGroup,
                                category: activeCategory
                            });
                            src = `leadlists.php?${params.toString()}`;
                        }
                        if (existingFrame && existingFrame.getAttribute('src') === src) {
                            if (sectionId === 'lead_lists') postLeadCategory();
                            return;
                        }
                        contentDiv.innerHTML = `<iframe src="${src}" style="background:var(--bg-color);"></iframe>`;
                        const frame = contentDiv.querySelector('iframe');
                        if (frame) {
                            frame.addEventListener('load', () => {
                                syncEmbeddedTheme();
                                if (sectionId === 'lead_lists') postLeadCategory();
                            }, { once: true });
                        }
                    }
                } catch (error) {
                    console.error('Error loading content:', error);
                    if (document.getElementById(`${sectionId}-content`)) {
                        document.getElementById(`${sectionId}-content`).innerHTML = 'Error loading content';
                    }
                } finally {
                    loading.style.display = 'none';
                }
            }

            function postLeadCategory() {
                const frame = document.querySelector('#lead_lists-content iframe');
                if (!frame || !frame.contentWindow) return;
                frame.contentWindow.postMessage({
                    type: 'setLeadListCategory',
                    category_group: activeCategoryGroup,
                    category: activeCategory
                }, window.location.origin);
            }

            function setActiveCategory(group, category, pushHistory) {
                activeCategoryGroup = group || '';
                activeCategory = category || '';
                document.querySelectorAll('.category-link').forEach(link => {
                    const isActive = link.dataset.group === activeCategoryGroup && link.dataset.category === activeCategory;
                    link.classList.toggle('active', isActive);
                    if (isActive) {
                        link.closest('.category-group')?.classList.add('open');
                        leadListsNavItem?.classList.add('categories-open');
                    }
                });

                navLinks.forEach(l => l.classList.remove('active'));
                document.getElementById('leadListsNavLink')?.classList.add('active');
                contentSections.forEach(s => s.classList.remove('active'));
                document.getElementById('lead_lists')?.classList.add('active');

                if (pushHistory) {
                    const params = new URLSearchParams({ section: 'lead_lists' });
                    if (activeCategoryGroup && activeCategory) {
                        params.set('category_group', activeCategoryGroup);
                        params.set('category', activeCategory);
                    }
                    window.history.pushState({}, '', '?' + params.toString());
                }

                loadContent('lead_lists');
            }

            window.addEventListener('popstate', function() {
                const params = new URLSearchParams(window.location.search);
                const section = params.get('section') || 'lead_lists';
                if (section === 'lead_lists') {
                    setActiveCategory(params.get('category_group') || '', params.get('category') || '', false);
                    return;
                }
                loadContent(section);
            });

            window.addEventListener('pageshow', function() {
                if (loading) loading.style.display = 'none';
            });

            setTimeout(() => {
                if (loading && loading.style.display !== 'none') {
                    console.warn('Loading spinner timed out, forcing hide');
                    loading.style.display = 'none';
                }
            }, 3000);

            const urlParams = new URLSearchParams(window.location.search);
            const paymentSuccess = urlParams.get('payment_success');
            const credits = urlParams.get('credits');

            if (paymentSuccess === 'true' && credits) {
                function createConfetti() {
                    const confetti = document.createElement('div');
                    confetti.style.width = '10px';
                    confetti.style.height = '10px';
                    confetti.style.background = `hsl(${Math.random() * 360}, 100%, 50%)`;
                    confetti.style.position = 'fixed';
                    confetti.style.top = '-10px';
                    confetti.style.left = `${Math.random() * 100}vw`;
                    confetti.style.borderRadius = '50%';
                    confetti.style.zIndex = '1000';
                    confetti.style.boxShadow = `0 0 5px ${confetti.style.background}`;
                    document.body.appendChild(confetti);

                    const animation = confetti.animate([
                        { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
                        { transform: `translateY(100vh) rotate(${Math.random() * 360}deg)`, opacity: 0 }
                    ], {
                        duration: Math.random() * 3000 + 2000,
                        easing: 'cubic-bezier(0,0,0.2,1)'
                    });

                    animation.onfinish = () => confetti.remove();
                }

                for (let i = 0; i < 100; i++) {
                    setTimeout(createConfetti, i * 20);
                }
                
                let confettiCount = 0;
                const confettiInterval = setInterval(() => {
                    createConfetti();
                    confettiCount++;
                    if (confettiCount > 50) {
                        clearInterval(confettiInterval);
                    }
                }, 100);

                const successMessage = document.createElement('div');
                successMessage.style.position = 'fixed';
                successMessage.style.top = '24px';
                successMessage.style.left = '50%';
                successMessage.style.transform = 'translateX(-50%)';
                successMessage.style.background = 'rgba(255, 255, 255, 0.9)';
                successMessage.style.backdropFilter = 'blur(20px)';
                successMessage.style.webkitBackdropFilter = 'blur(20px)';
                successMessage.style.color = '#1d1d1f';
                successMessage.style.padding = '20px 32px';
                successMessage.style.borderRadius = '16px';
                successMessage.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.12)';
                successMessage.style.border = '1px solid rgba(0, 0, 0, 0.06)';
                successMessage.style.zIndex = '1000';
                successMessage.style.textAlign = 'center';
                successMessage.innerHTML = `
                    <h3 style="margin-bottom: 8px; font-size: 18px; font-weight: 700;">Payment Successful!</h3>
                    <p style="color: #86868b; font-size: 15px;">${new Intl.NumberFormat().format(credits)} credits have been added to your account.</p>
                `;
                document.body.appendChild(successMessage);

                setTimeout(() => {
                    successMessage.style.opacity = '0';
                    successMessage.style.transition = 'opacity 0.5s ease';
                    setTimeout(() => successMessage.remove(), 500);
                }, 5000);

                window.history.replaceState({}, '', '?section=lead_lists');
            }

            function updateCredits() {
                fetch('pricing.php?action=get_credits')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const credits = parseInt(data.credits);
                            if (!isNaN(credits)) {
                                document.querySelectorAll('.credits-pill').forEach(el => {
                                    el.textContent = new Intl.NumberFormat().format(credits);
                                });
                                if (credits === 0 && window.location.search.indexOf('section=section5') === -1) {
                                    window.location.href = '?section=section5';
                                }
                            }
                        }
                    })
                    .catch(error => console.error('Error updating credits:', error));
            }

            window.addEventListener('message', function(event) {
                if (event.data.type === 'creditUpdate') {
                    const credits = parseInt(event.data.credits);
                    if (!isNaN(credits)) {
                        document.querySelectorAll('.credits-pill').forEach(el => {
                            el.textContent = new Intl.NumberFormat().format(credits);
                        });
                        if (credits === 0 && window.location.search.indexOf('section=section5') === -1) {
                            window.location.href = '?section=section5';
                        }
                    }
                }
            });

            document.addEventListener('visibilitychange', function() {
                if (document.visibilityState === 'visible') updateCredits();
            });

            document.querySelectorAll('.nav-link').forEach(link => {
                if (link.querySelector('.fa-chevron-down')) {
                    link.addEventListener('click', function(e) {
                        if (this.id === 'leadListsNavLink') return;
                        e.preventDefault();
                        e.stopPropagation();
                        
                        const submenu = this.nextElementSibling;
                        const chevron = this.querySelector('.fa-chevron-down');
                        
                        this.classList.toggle('expanded');
                        submenu.classList.toggle('active');
                    });
                }
            });

            document.querySelectorAll('.submenu-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const sectionId = this.getAttribute('href').replace('?section=', '');
                    
                    document.querySelectorAll('.submenu-link').forEach(l => l.classList.remove('active'));
                    document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
                    
                    this.classList.add('active');
                    document.getElementById(sectionId).classList.add('active');
                    
                    loadContent(sectionId);
                    
                    window.history.pushState({}, '', `?section=${sectionId}`);

                    if (window.innerWidth <= 768) {
                        sidebar.classList.remove('active');
                    }
                });
            });
        });
    </script>
</body>
</html>
