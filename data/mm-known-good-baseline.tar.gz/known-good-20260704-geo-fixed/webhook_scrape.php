<?php
require_once 'config/database.php';

// ---------------------------------------------------------------------------
// Auth gate (audit S-C1, 2026-07-04):
// Reject any unauthenticated callback. Identity is verified against the same
// shared token (DB_SCHEMA_PROBE_TOKEN) used by the other worker endpoints,
// because the .env does not currently ship a REPLICATE_WEBHOOK_SECRET.
// Valid Replicate callbacks reach this endpoint only when Replicate is
// configured to send X-API-Token via the worker, or through internal server-
// side callers in recoverStuckEnrichments / retryFailedEnrichments / fireAllScrapes.
// Anonymous HTTP requests can no longer mutate lead_list_items.
// ---------------------------------------------------------------------------
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$expected_token = '';
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (strpos($line, '#') === 0 || strpos($line, '=') === false) continue;
        list($key, $val) = explode('=', $line, 2);
        $key = trim($key);
        $val = trim($val);
        if (preg_match('/^([\'"])(.*)\1$/', $val, $m)) $val = $m[2];
        if ($key === 'DB_SCHEMA_PROBE_TOKEN') { $expected_token = $val; break; }
    }
}
$h = $_SERVER['HTTP_X_API_TOKEN'] ?? '';
$q = $_GET['t'] ?? '';
// X-API-Token header preferred; fall back to ?t= URL parameter for
// services (e.g. Replicate webhooks) that cannot add custom headers.
$received_token = $h !== '' ? $h : $q;
if (empty($expected_token) || !hash_equals($expected_token, $received_token)) {
    http_response_code(401);
    echo json_encode(['error' => 'UNAUTHORIZED']);
    exit;
}

$body = file_get_contents('php://input');
$data = json_decode($body, true);

if (!$data || !isset($data['id'])) {
    http_response_code(400);
    exit;
}

$leadId = intval($_GET['lead_id'] ?? 0);
$listId = intval($_GET['list_id'] ?? 0);
$replicateId = $data['id'] ?? '';

if (!$leadId || !$listId) {
    http_response_code(200);
    exit;
}

if ($replicateId) {
    $pdo->prepare("UPDATE lead_list_items SET replicate_id = COALESCE(replicate_id, ?) WHERE id = ? AND list_id = ?")
        ->execute([$replicateId, $leadId, $listId]);
}

$status = $data['status'] ?? '';
if ($status !== 'succeeded') {
    if (in_array($status, ['failed', 'canceled'])) {
        $pdo->prepare("UPDATE lead_list_items SET enriched_at = NOW(), enrichment_status = 'failed' WHERE id = ? AND list_id = ?")
            ->execute([$leadId, $listId]);
    }
    http_response_code(200);
    exit;
}

$output = $data['output'] ?? [];
$htmlContent = $output['html_content'] ?? $output['text_content'] ?? '';

if (!$htmlContent) {
    $pdo->prepare("UPDATE lead_list_items SET enriched_at = NOW(), enrichment_status = 'completed' WHERE id = ? AND list_id = ?")
        ->execute([$leadId, $listId]);
    http_response_code(200);
    exit;
}

$spamDomains = [
    'sentry.io', 'sentry.wixpress.com', 'sentry-next.wixpress.com',
    'wixpress.com', 'example.com', 'sentry.', 'noreply', 'no-reply',
    'localhost', 'test.com', 'email.com', 'domain.com', 'yoursite.com',
    'company.com', 'website.com', 'sample.com', 'placeholder',
    'wordpress.org', 'wordpress.com', 'w3.org', 'schema.org',
    'googleusercontent.com', 'gstatic.com', 'googleapis.com',
    'apple.com', 'icloud.com', 'microsoft.com', 'outlook.com',
    'squarespace.com', 'weebly.com', 'shopify.com', 'wix.com',
    'godaddy.com', 'cloudflare.com',
    'group.calendar.google.com', 'calendar.google.com',
    'mysite.com', 'mywebsite.com', 'mycompany.com', 'mydomain.com',
    'address.com', 'company.site', 'yourcompany.com', 'yourdomain.com',
    'yourname.com', 'sitebuilder.com', 'templatemonster.com'
];

$spamPatterns = [
    '/^.{0,2}@/',
    '/^\.\+@/',
    '/@\d+\.\d+/',
    '/^[a-f0-9]{20,}@/',
    '/^[0-9]+@/',
    '/\.(js|css|php|html|json|xml|svg|png|jpg|jpeg|gif|webp|avif|bmp|ico|woff|woff2|ttf|eot|otf|mp4|mp3|pdf|zip|doc|docx)$/i',
    '/@.*@/',
    '/^(admin|info|support|contact|hello|help|sales|billing|abuse|postmaster|webmaster|hostmaster|mailer-daemon|noreply|no-reply)@(gmail|yahoo|hotmail|outlook)\./i',
    '/^(example|test|user|name|email|your|sample|demo|placeholder|changeme|first\.?last|john\.?doe|jane\.?doe)@/i',
    '/^[a-z0-9]{25,}@/i',
    '/@group\.calendar\./i'
];

preg_match_all('/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/', $htmlContent, $emailMatches);
$rawEmails = array_unique($emailMatches[0] ?? []);
$cleanEmails = [];

foreach ($rawEmails as $email) {
    $email = strtolower(trim($email));
    if (strlen($email) < 6 || strlen($email) > 254) continue;

    $isSpam = false;
    foreach ($spamDomains as $sd) {
        if (stripos($email, $sd) !== false) { $isSpam = true; break; }
    }
    if ($isSpam) continue;

    foreach ($spamPatterns as $pat) {
        if (preg_match($pat, $email)) { $isSpam = true; break; }
    }
    if ($isSpam) continue;

    $parts = explode('@', $email);
    if (count($parts) !== 2) continue;
    $local = $parts[0];
    $domain = $parts[1];

    if (strlen($local) < 2 || strlen($local) > 64) continue;
    if (substr_count($domain, '.') < 1) continue;
    if (preg_match('/^\d+\.\d+\.\d+$/', $domain)) continue;
    if (preg_match('/^[a-f0-9]{24,}$/', $local)) continue;
    if (!preg_match('/^[a-zA-Z]/', $local)) continue;

    $cleanEmails[] = $email;
}
$cleanEmails = array_values(array_slice($cleanEmails, 0, 10));

$socialDomains = [
    'facebook.com', 'fb.com', 'fb.me',
    'instagram.com', 'instagr.am',
    'twitter.com', 'x.com',
    'linkedin.com',
    'youtube.com', 'youtu.be',
    'tiktok.com',
    'pinterest.com',
    'yelp.com'
];
preg_match_all('/https?:\/\/[^\s"\'<>]+/i', $htmlContent, $urlMatches);
$socialLinks = [];
foreach (array_unique($urlMatches[0] ?? []) as $foundUrl) {
    foreach ($socialDomains as $sp) {
        if (stripos($foundUrl, $sp) !== false) {
            $cleanSocial = preg_replace('/["\'>)}\]]+$/', '', $foundUrl);
            if (strlen($cleanSocial) > strlen($sp) + 12) {
                $socialLinks[] = $cleanSocial;
            }
            break;
        }
    }
}
$socialLinks = array_values(array_unique(array_slice($socialLinks, 0, 20)));

$stmt = $pdo->prepare("SELECT emails, social_media_links FROM lead_list_items WHERE id = ? AND list_id = ?");
$stmt->execute([$leadId, $listId]);
$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existing) {
    $existingEmails = json_decode($existing['emails'] ?: '[]', true);
    $existingSocials = json_decode($existing['social_media_links'] ?: '[]', true);

    $mergedEmails = array_values(array_unique(array_merge($existingEmails, $cleanEmails)));
    $mergedSocials = array_values(array_unique(array_merge($existingSocials, $socialLinks)));

    $pdo->prepare("UPDATE lead_list_items SET emails = ?, social_media_links = ?, has_email = ?, has_socials = ?, enriched_at = NOW(), enrichment_status = 'completed' WHERE id = ? AND list_id = ?")
        ->execute([json_encode($mergedEmails), json_encode($mergedSocials), !empty($mergedEmails) ? 1 : 0, !empty($mergedSocials) ? 1 : 0, $leadId, $listId]);
}

http_response_code(200);
