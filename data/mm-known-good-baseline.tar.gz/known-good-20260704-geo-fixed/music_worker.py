#!/usr/bin/env python3
"""
Music Metrics VPS Worker
Runs from systemd timer to process lead enrichment queue.
"""

import os
import sys
import json
import time
import re
import urllib.request
import urllib.error
import fcntl

# Constants & Paths
LOCK_FILE = '/tmp/music_worker.lock'
STATE_FILE = '/root/logs/music_worker.state'
LOG_FILE = '/root/logs/music_worker.log'

CPANEL_TOKEN_FILE = '/root/.secrets/saas_db_probe_token_music'
REPLICATE_TOKEN_FILE = '/root/.secrets/music_metrics_replicate_key_new.txt'

STATUS_URL = 'https://music-metrics.com/worker_status.php'
PAUSE_URL = 'https://music-metrics.com/worker_pause.php'
CLAIM_URL = 'https://music-metrics.com/queue_claim.php'
RESULT_URL = 'https://music-metrics.com/scrape_result.php'

MODEL_VERSION = 'e4321bcdf8cc522da43519a17baf748c675710bad1d3db9f57aaad29f805ac19'

# Spam Filtering Lists & RegEx
SPAM_DOMAINS = [
    'sentry.io', 'sentry.wixpress.com', 'sentry-next.wixpress.com',
    'wixpress.com', 'example.com', 'sentry.', 'noreply', 'no-reply',
    'localhost', 'test.com', 'email.com', 'domain.com', 'yoursite.com',
    'company.com', 'website.com', 'sample.com', 'placeholder',
    'wordpress.org', 'wordpress.com', 'w3.org', 'schema.org',
    'googleusercontent.com', 'gstatic.com', 'googleapis.com',
    'apple.com', 'icloud.com', 'microsoft.com', 'outlook.com',
    'squarespace.com', 'weebly.com', 'shopify.com', 'wix.com',
    'godaddy.com', 'cloudflare.com', 'group.calendar.google.com',
    'calendar.google.com', 'mysite.com', 'mywebsite.com', 'mycompany.com',
    'mydomain.com', 'address.com', 'company.site', 'yourcompany.com',
    'yourdomain.com', 'yourname.com', 'sitebuilder.com', 'templatemonster.com'
]

SPAM_PATTERNS = [
    r'^.{0,2}@',
    r'^\.\+@',
    r'@\d+\.\d+',
    r'^[a-f0-9]{20,}@',
    r'^[0-9]+@',
    r'\.(js|css|php|html|json|xml|svg|png|jpg|jpeg|gif|webp|avif|bmp|ico|woff|woff2|ttf|eot|otf|mp4|mp3|pdf|zip|doc|docx)$',
    r'@.*@',
    r'^(admin|info|support|contact|hello|help|sales|billing|abuse|postmaster|webmaster|hostmaster|mailer-daemon|noreply|no-reply)@(gmail|yahoo|hotmail|outlook)\.',
    r'^(example|test|user|name|email|your|sample|demo|placeholder|changeme|first\.?last|john\.?doe|jane\.?doe)@',
    r'^[a-z0-9]{25,}@',
    r'@group\.calendar\.'
]

SOCIAL_DOMAINS = [
    'facebook.com', 'fb.com', 'fb.me',
    'instagram.com', 'instagr.am',
    'twitter.com', 'x.com',
    'linkedin.com',
    'youtube.com', 'youtu.be',
    'tiktok.com',
    'pinterest.com',
    'yelp.com'
]

def log(msg):
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, 'a') as f:
            f.write(line + '\n')
    except OSError:
        pass

def load_secret(path):
    try:
        with open(path, 'r') as f:
            return f.read().strip()
    except OSError:
        return ''

def get_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {'consecutive_empty': 0, 'allowed_run_time': 0, 'halted': False}

def save_state(state):
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f)
    except OSError:
        pass

def parse_emails(html):
    if not html:
        return []
    matches = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', html)
    unique_emails = list(set(matches))
    clean = []
    for email in unique_emails:
        email = email.lower().strip()
        if len(email) < 6 or len(email) > 254:
            continue
        is_spam = False
        for sd in SPAM_DOMAINS:
            if sd in email:
                is_spam = True
                break
        if is_spam:
            continue
        for pat in SPAM_PATTERNS:
            if re.search(pat, email, re.IGNORECASE):
                is_spam = True
                break
        if is_spam:
            continue
        parts = email.split('@')
        if len(parts) != 2:
            continue
        local, domain = parts
        if len(local) < 2 or len(local) > 64:
            continue
        if domain.count('.') < 1:
            continue
        if re.match(r'^\d+\.\d+\.\d+$', domain):
            continue
        if re.match(r'^[a-f0-9]{24,}$', local):
            continue
        if not re.match(r'^[a-zA-Z]', local):
            continue
        clean.append(email)
    return clean[:10]

def parse_socials(html):
    if not html:
        return []
    matches = re.findall(r'https?://[^\s"\'<>]+', html)
    socials = []
    for url in list(set(matches)):
        for domain in SOCIAL_DOMAINS:
            if domain in url:
                clean = re.sub(r'["\'>)}\]]+$', '', url)
                if len(clean) > len(domain) + 12:
                    socials.append(clean)
                break
    return list(set(socials))[:20]

def make_request(url, method='GET', data=None, headers=None, timeout=30):
    if headers is None:
        headers = {}
    payload = None
    if data is not None:
        payload = json.dumps(data).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    
    req = urllib.request.Request(url, data=payload, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode('utf-8')
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8')
    except Exception as e:
        return 0, str(e)

def trigger_replicate(website_url, replicate_token):
    payload = {
        'version': MODEL_VERSION,
        'input': {'url': website_url}
    }
    headers = {
        'Authorization': f"Bearer {replicate_token}",
        'Content-Type': 'application/json'
    }
    req = urllib.request.Request(
        'https://api.replicate.com/v1/predictions',
        data=json.dumps(payload).encode('utf-8'),
        headers=headers,
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            if resp.status == 201 or resp.status == 200:
                res_data = json.loads(resp.read().decode('utf-8'))
                return True, res_data.get('id', ''), ''
            return False, '', f"HTTP {resp.status}"
    except urllib.error.HTTPError as e:
        try:
            err_data = json.loads(e.read().decode('utf-8'))
            detail = err_data.get('detail', f"HTTP {e.code}")
        except Exception:
            detail = f"HTTP {e.code}"
        return False, '', detail
    except Exception as e:
        return False, '', str(e)

def poll_replicate(prediction_id, replicate_token, timeout_sec=45):
    headers = {
        'Authorization': f"Bearer {replicate_token}"
    }
    url = f"https://api.replicate.com/v1/predictions/{prediction_id}"
    req = urllib.request.Request(url, headers=headers, method='GET')
    
    start_time = time.time()
    while time.time() - start_time < timeout_sec:
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    status = data.get('status')
                    if status == 'succeeded':
                        output = data.get('output', {})
                        html = output.get('html_content') or output.get('text_content') or ''
                        return True, html, ''
                    elif status in ['failed', 'canceled']:
                        return False, '', f"Replicate status: {status}"
        except Exception as e:
            log(f"  WARN: Poll exception for prediction {prediction_id}: {e}")
        time.sleep(3)
    return False, '', "TIMEOUT"

def main():
    # 1. Enforce lockfile
    lock_file = open(LOCK_FILE, 'w')
    try:
        fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("Worker lock collision. Exiting.")
        sys.exit(0)

    # 2. Check state and backoff
    state = get_state()
    if state.get('halted'):
        log("HALTED: Credentials validation failed. Manual reset required.")
        sys.exit(0)

    allowed_run_time = state.get('allowed_run_time', 0)
    if time.time() < allowed_run_time:
        sys.exit(0)

    # 3. Read auth token
    api_token = load_secret(CPANEL_TOKEN_FILE)
    if not api_token:
        log("CRITICAL: API Token not found locally.")
        sys.exit(1)

    # 4. Check worker status (worker_status.php requires X-API-Token per S-C2 audit fix)
    headers = {'X-API-Token': api_token}
    status_code, body = make_request(STATUS_URL, headers=headers)
    if status_code != 200:
        log(f"CRITICAL: Failed to query status. HTTP {status_code}")
        sys.exit(1)

    try:
        status_data = json.loads(body)
    except Exception:
        log("CRITICAL: Failed to parse status response.")
        sys.exit(1)

    if status_data.get('worker_paused') is True:
        log(f"PAUSED: Skipping execution. Reason: {status_data.get('pause_reason')}")
        sys.exit(0)

    # 5. Attempt queue claim
    code, claim_body = make_request(CLAIM_URL, method='POST', data={}, headers=headers)

    if code == 401:
        log("CRITICAL: 401 Unauthorized. Halting worker execution permanently.")
        state['halted'] = True
        save_state(state)
        sys.exit(1)

    if code == 403:
        log("PAUSED: 403 Forbidden. Queue claim paused.")
        sys.exit(0)

    if code != 200:
        log(f"ERROR: Queue claim failed. HTTP {code}")
        sys.exit(1)

    try:
        claim_data = json.loads(claim_body)
    except Exception:
        log("ERROR: Failed to parse queue claim JSON response.")
        sys.exit(1)

    worker_run_id = claim_data.get('worker_run_id')
    leads = claim_data.get('leads', [])

    # 6. Stateful empty queue backoff
    if not leads:
        consec = state.get('consecutive_empty', 0) + 1
        state['consecutive_empty'] = consec
        
        # Calculate backoff
        if consec == 1:
            delay = 60
        elif consec == 2:
            delay = 300
        elif consec == 3:
            delay = 600
        else:
            delay = 900
            
        state['allowed_run_time'] = time.time() + delay
        save_state(state)
        log(f"Queue empty. Consecutive={consec}. Next poll allowed in {delay}s.")
        sys.exit(0)

    # Reset backoff counters since queue has items
    state['consecutive_empty'] = 0
    state['allowed_run_time'] = 0
    save_state(state)

    replicate_token = load_secret(REPLICATE_TOKEN_FILE)
    if not replicate_token:
        log("CRITICAL: Replicate API token not found on VPS.")
        sys.exit(1)

    log(f"Processing batch of {len(leads)} leads. RunID={worker_run_id}")
    
    consecutive_errors = 0
    success_count = 0

    for lead in leads:
        lead_id = lead['id']
        list_id = lead['list_id']
        website = lead['website'] or ''
        
        log(f" Lead ID {lead_id}: {website}")
        
        # Format URL
        url = website.strip()
        if not re.match(r'^https?://', url, re.IGNORECASE):
            url = 'https://' + url

        # A. Trigger Replicate
        ok, prediction_id, err_msg = trigger_replicate(url, replicate_token)
        if not ok:
            log(f"   TRIGGER FAILED: {err_msg}")
            consecutive_errors += 1
            # Submit failure result
            result_payload = {
                'worker_run_id': worker_run_id,
                'lead_id': lead_id,
                'list_id': list_id,
                'status': 'failed',
                'error': err_msg
            }
            make_request(RESULT_URL, method='POST', data=result_payload, headers=headers)
            continue

        log(f"   Triggered prediction_id: {prediction_id}")

        # B. Poll Replicate for completion
        poll_ok, html_content, poll_err = poll_replicate(prediction_id, replicate_token)
        if not poll_ok:
            log(f"   POLLING FAILED: {poll_err}")
            consecutive_errors += 1
            result_payload = {
                'worker_run_id': worker_run_id,
                'lead_id': lead_id,
                'list_id': list_id,
                'status': 'failed',
                'error': poll_err
            }
            make_request(RESULT_URL, method='POST', data=result_payload, headers=headers)
            continue

        # C. Parse outputs
        emails = parse_emails(html_content)
        socials = parse_socials(html_content)
        log(f"   SUCCESS: emails={len(emails)} socials={len(socials)}")
        success_count += 1
        consecutive_errors = 0 # reset error tally on row success

        # D. Post results
        result_payload = {
            'worker_run_id': worker_run_id,
            'lead_id': lead_id,
            'list_id': list_id,
            'status': 'succeeded',
            'emails': emails,
            'socials': socials
        }
        res_code, res_body = make_request(RESULT_URL, method='POST', data=result_payload, headers=headers)
        if res_code != 200:
            log(f"   WARN: Submit results failed with HTTP {res_code}: {res_body}")

        # Throttling delay
        time.sleep(3)

        # 7. Check failure throttling thresholds
        if consecutive_errors >= 4:
            log("CRITICAL: Encountered 4 consecutive scraping failures. Pausing worker settings.")
            pause_payload = {'reason': 'consecutive_errors'}
            make_request(PAUSE_URL, method='POST', data=pause_payload, headers=headers)
            break

    log(f"Batch completed. Success={success_count}/{len(leads)}")

if __name__ == '__main__':
    main()
