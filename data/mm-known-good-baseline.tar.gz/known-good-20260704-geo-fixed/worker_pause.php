<?php
/**
 * Worker Pause Endpoint - Authenticated
 * Allows the worker to pause execution on critical errors.
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'METHOD_NOT_ALLOWED']);
    exit;
}

// 1. Load expected DB_SCHEMA_PROBE_TOKEN from .env file
$expected_token = '';
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (strpos($line, '#') === 0 || strpos($line, '=') === false) {
            continue;
        }
        list($key, $val) = explode('=', $line, 2);
        $key = trim($key);
        $val = trim($val);
        if (preg_match('/^([\'"])(.*)\1$/', $val, $m)) {
            $val = $m[2];
        }
        if ($key === 'DB_SCHEMA_PROBE_TOKEN') {
            $expected_token = $val;
            break;
        }
    }
}

// 2. Validate Authorization Token
$received_token = $_SERVER['HTTP_X_API_TOKEN'] ?? '';
if (empty($expected_token) || !hash_equals($expected_token, $received_token)) {
    http_response_code(401);
    echo json_encode(['error' => 'UNAUTHORIZED']);
    exit;
}

// 3. Connect to Database
try {
    @include_once __DIR__ . '/config/database.php';
    if (!isset($pdo) || !$pdo instanceof PDO) {
        http_response_code(500);
        echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
        exit;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
    exit;
}

// 4. Parse input payload
$body = file_get_contents('php://input');
$data = json_decode($body, true);
$reason = trim($data['reason'] ?? 'manual');

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("UPDATE worker_settings SET setting_value = '1' WHERE setting_key = 'worker_paused'");
    $stmt->execute();

    $stmt = $pdo->prepare("UPDATE worker_settings SET setting_value = ? WHERE setting_key = 'pause_reason'");
    $stmt->execute([$reason]);

    $stmt = $pdo->prepare("UPDATE worker_settings SET setting_value = NOW() WHERE setting_key = 'paused_at'");
    $stmt->execute();

    $stmt = $pdo->prepare("UPDATE worker_settings SET setting_value = 'worker' WHERE setting_key = 'paused_by'");
    $stmt->execute();

    $pdo->commit();

    echo json_encode(['status' => 'OK']);
    exit;

} catch (Throwable $e) {
    if ($pdo && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error' => 'MIGRATION_FAILED']);
    exit;
}
