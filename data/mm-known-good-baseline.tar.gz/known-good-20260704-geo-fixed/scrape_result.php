<?php
/**
 * Scrape Result Submission Endpoint - Authenticated
 * Receives scraped data from the VPS worker and applies updates, verifying worker_run_id ownership.
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'METHOD_NOT_ALLOWED']);
    exit;
}

// 1. Load expected DB_SCHEMA_PROBE_TOKEN from .env file
$expected_token = '';
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (strpos($line, '#') === 0 || strpos($line, '=') === false) {
            continue;
        }
        list($key, $val) = explode('=', $line, 2);
        $key = trim($key);
        $val = trim($val);
        if (preg_match('/^([\'"])(.*)\1$/', $val, $m)) {
            $val = $m[2];
        }
        if ($key === 'DB_SCHEMA_PROBE_TOKEN') {
            $expected_token = $val;
            break;
        }
    }
}

// 2. Validate Authorization Token
$received_token = $_SERVER['HTTP_X_API_TOKEN'] ?? '';
if (empty($expected_token) || !hash_equals($expected_token, $received_token)) {
    http_response_code(401);
    echo json_encode(['error' => 'UNAUTHORIZED']);
    exit;
}

// 3. Connect to Database
try {
    @include_once __DIR__ . '/config/database.php';
    if (!isset($pdo) || !$pdo instanceof PDO) {
        http_response_code(500);
        echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
        exit;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'DATABASE_UNAVAILABLE']);
    exit;
}

// 4. Parse POST input payload
$body = file_get_contents('php://input');
$data = json_decode($body, true);

$workerRunId = trim($data['worker_run_id'] ?? '');
$leadId = intval($data['lead_id'] ?? 0);
$listId = intval($data['list_id'] ?? 0);
$status = trim($data['status'] ?? '');
$emails = $data['emails'] ?? [];
$socials = $data['socials'] ?? [];
$errorMsg = trim($data['error'] ?? '');

if (empty($workerRunId) || !$leadId || !$listId || !in_array($status, ['succeeded', 'failed'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'INVALID_PAYLOAD']);
    exit;
}

try {
    // 5. Query existing lead to verify run ownership
    $stmt = $pdo->prepare("
        SELECT worker_run_id, enrichment_status 
        FROM lead_list_items 
        WHERE id = ? AND list_id = ?
    ");
    $stmt->execute([$leadId, $listId]);
    $lead = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$lead) {
        http_response_code(404);
        echo json_encode(['error' => 'LEAD_NOT_FOUND']);
        exit;
    }

    if ($lead['worker_run_id'] !== $workerRunId || $lead['enrichment_status'] !== 'processing') {
        http_response_code(409);
        echo json_encode(['error' => 'OWNERSHIP_MISMATCH_OR_STALE_RUN']);
        exit;
    }

    // 6. Apply updates based on status
    if ($status === 'succeeded') {
        // Enforce deduplicated arrays
        $emailsJson = json_encode(array_values(array_unique(array_filter(array_map('strtolower', $emails)))));
        $socialsJson = json_encode(array_values(array_unique(array_filter($socials))));
        $hasEmail = !empty($emails) ? 1 : 0;
        $hasSocials = !empty($socials) ? 1 : 0;

        $updateStmt = $pdo->prepare("
            UPDATE lead_list_items
            SET emails = ?,
                social_media_links = ?,
                has_email = ?,
                has_socials = ?,
                enriched_at = NOW(),
                enrichment_status = 'completed',
                worker_run_id = NULL
            WHERE id = ? 
              AND list_id = ? 
              AND worker_run_id = ?
              AND enrichment_status = 'processing'
        ");
        $updateStmt->execute([$emailsJson, $socialsJson, $hasEmail, $hasSocials, $leadId, $listId, $workerRunId]);
    } else {
        $updateStmt = $pdo->prepare("
            UPDATE lead_list_items
            SET last_error = ?,
                enriched_at = NOW(),
                enrichment_status = 'failed',
                worker_run_id = NULL
            WHERE id = ? 
              AND list_id = ? 
              AND worker_run_id = ?
              AND enrichment_status = 'processing'
        ");
        $updateStmt->execute([$errorMsg, $leadId, $listId, $workerRunId]);
    }

    echo json_encode(['status' => 'OK']);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'UPDATE_FAILED']);
    exit;
}
