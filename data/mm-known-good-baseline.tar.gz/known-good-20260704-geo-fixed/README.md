# Known-Good Baseline — 2026-07-04 (Geo Selector Fixed)

This folder is the **authoritative known-good baseline** for Music Metrics as of 2026-07-04, after the Top Cities / geo-selector SQL-ambiguity fix was deployed and verified.

## Identity

| Field | Value |
|---|---|
| **Variant folder** | `known-good-20260704-geo-fixed/` |
| **leadlists.php SHA256 (live)** | `9a7dc2397e2daf2ce7033cafcc1babe4bcfd97af72687d34279dc55245e310a6` |
| **leadlists.php size** | 597,814 bytes |
| **Fixing commit (source repo `music-metrics-source`)** | `3990deb76a960ab8d130ff4b169730e3fedb4a33` — "Fix SQL ambiguity in getTopCities and add client-side caching for getCities and getTopCities" |
| **Deployment date/time** | 2026-07-04 (deployed via `deploy-saas-public-file`; closeout report filed same day) |
| **Closeout report** | `/root/agent-work/MUSIC_METRICS_GEO_SELECTOR_FIX_20260704.md` |
| **Catalogue report** | `/root/agent-work/MUSIC_METRICS_SOURCE_OF_TRUTH_CATALOG_20260704.md` |
| **Backup snapshot** | `/root/backups/music_known_good_20260704_geo_fixed/` |
| **Git tag (this repo)** | `music-metrics-known-good-20260704-geo-fixed` |

## Operator Manual Check — PASSED

Full server-side integration test matrix verified on live (closeout report §3):

| Preset | Result | Count | Sample |
|---|---|---|---|
| US Top 100 | ✅ | 100 | New York, Los Angeles, Chicago, Brooklyn, Houston |
| Canada Top 100 | ✅ | 100 | Toronto, Montréal, Calgary, Ottawa, Edmonton |
| UK Top 100 | ✅ | 100 | London, Birmingham, Portsmouth, Southampton, Bristol |
| EU / France Top 100 | ✅ | 100 | Paris, Marseille, Lyon, Toulouse, Nice |
| LATAM / Mexico Top 100 | ✅ | 100 | Mexico City, Tijuana, Iztapalapa, Puebla, Ecatepec de Morelos |

## What this baseline preserves (MUST NOT regress)

1. **`STALE-QUEUED-CLEANUP-V2`** — `DELETE` before `INSERT IGNORE` in `enqueueScrapeCities` (unique-key slot reclaim).
2. **Qualified geo sort** — `getTopCities` orders by qualified `c.population` (fixes `Column 'population' in ORDER BY is ambiguous`).
3. **Client-side cache** — `getCities` and `getTopCities` present in `cacheableGetActions`.
4. **Geo cascade** — US/UK/EU/CA-LAT/CAR/AF/ME-CA/RU-CN/SA-SEA-OC intact.
5. **Auth gates** — `X-API-Token` gate on `webhook_scrape.php`, `worker_status.php`, `queue_claim.php`, `scrape_result.php`.
6. **No Replicate fan-out** — `0` direct `api.replicate.com/v1/predictions`; `0` `curl_multi_init`.

## Files (see `SHA256SUMS`)

`leadlists.php`, `dashboard.php`, `worker_status.php`, `webhook_scrape.php`, `queue_claim.php`, `scrape_result.php`, `worker_pause.php`, `music_worker.py`.

## Lockdown rules (operator policy)

- **No further Music Metrics mutation** unless the operator explicitly names Music Metrics AND says EXECUTE in the current prompt.
- **Deploy only from committed source-of-truth** (this repo). Never deploy guarded-helper wrapper JSON.
- **No Phase 2 static-asset extraction** (inline CSS/JS → `assets/music-metrics/`) unless planned as a separate small lane.
- **Before any future Music Metrics change**, diff against tag `music-metrics-known-good-20260704-geo-fixed` and confirm the six preservation points above remain intact.
