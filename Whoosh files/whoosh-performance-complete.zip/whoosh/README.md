# Whoosh Performance

A single-page landing site reproducing the supplied https://www.whoosh.health/ reference, rebranded for https://www.whooshperformance.com/. The original layout, photographs, golden hero video, fonts, plan descriptions and FAQs are retained. The original site's tracking, booking destination, address and telephone number are removed.

## Run

```sh
python3 -m http.server 3000 --bind 0.0.0.0 --directory public
```

The publication output is the committed `public/` folder; no build dependencies are required. The route manifest is `public/manus-routes.json`.

## Contact

All inquiries use `info@whooshperformance.com`, confirmed by the user. Header and pricing actions lead to the on-page contact section. The contact form composes a prefilled email using the visitor's email application. The visitor must complete sending there. No email API, server-side delivery, submission storage or mailbox provisioning is claimed.

## Structure

`public/index.html` contains the meaningful page content and metadata. `reference.css` preserves the original visual styling. `performance.css` and `performance.js` provide rebranding-related styles, responsive menus, accessible FAQs, mobile sliders, policy dialogs and the email inquiry action. `public/assets/` contains local reference images, fonts, video and Swiper. `reference/` stores the original supplied-page source used for adaptation. `scripts/build_reference.py` is the reproducible importer.

The original policy copy is retained in rebranded on-page dialogs; the owner should review it and the reference's pricing, clinical statements and partner claims before public launch. This does not establish any affiliation or operational capacity beyond the user's supplied content.

## Domain

The supplied custom domain is reflected in page metadata. A preview does not connect that domain or configure its DNS. Domain connection and public publication are separate from saving this site version.
