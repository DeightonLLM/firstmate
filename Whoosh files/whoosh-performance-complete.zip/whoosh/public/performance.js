(() => {
  'use strict';

  const CONTACT_EMAIL = 'info@whooshperformance.com';
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const nav = document.querySelector('.mega-nav');
  const menu = document.querySelector('[data-burger-toggle]');
  const mobileNav = document.querySelector('[data-mobile-nav]');
  const form = document.querySelector('#inquiry-form');
  const status = document.querySelector('#inquiry-status');
  let previouslyFocused = null;

  if (menu && mobileNav) {
    mobileNav.id = 'mobile-navigation';
    menu.setAttribute('aria-controls', mobileNav.id);
  }

  function setMenu(open) {
    if (!nav || !menu) return;
    nav.setAttribute('data-menu-open', String(open));
    menu.setAttribute('aria-expanded', String(open));
    menu.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    menu.textContent = open ? 'Close' : 'Menu';
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) nav.classList.remove('is-nav-hidden');
  }

  menu?.addEventListener('click', () => {
    setMenu(menu.getAttribute('aria-expanded') !== 'true');
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menu?.getAttribute('aria-expanded') === 'true') {
      setMenu(false);
      menu.focus();
    }
    if (event.key !== 'Tab' || menu?.getAttribute('aria-expanded') !== 'true') return;
    const links = Array.from(mobileNav.querySelectorAll('a[href]'));
    const first = links[0];
    const last = links[links.length - 1];
    if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      menu.focus();
    } else if (event.shiftKey && document.activeElement === menu) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === menu) {
      event.preventDefault();
      first?.focus();
    }
  });

  let lastScroll = window.scrollY;
  window.addEventListener('scroll', () => {
    const currentScroll = window.scrollY;
    nav?.classList.toggle('is-scroll', currentScroll > 100);
    if (menu?.getAttribute('aria-expanded') !== 'true') {
      nav?.classList.toggle('is-nav-hidden', currentScroll > lastScroll && currentScroll > 200);
    }
    lastScroll = currentScroll;
  }, { passive: true });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 991) setMenu(false);
  });

  // Every sales action is internal. Demo/plan actions select the inquiry topic.
  document.querySelectorAll('a[href^="#"]:not([data-policy])').forEach((link) => {
    link.addEventListener('click', (event) => {
      const targetId = link.getAttribute('href').slice(1);
      const target = document.getElementById(targetId);
      if (!target) return;
      event.preventDefault();
      setMenu(false);
      if (link.dataset.inquiry && form) {
        form.elements.namedItem('interest').value = link.dataset.inquiry;
        status.textContent = '';
      }
      target.scrollIntoView({ behavior: reducedMotion ? 'instant' : 'smooth', block: 'start' });
      history.replaceState(null, '', '#' + targetId);
    });
  });

  // Accessible accordion, including keyboard operation and one-at-a-time opening.
  document.querySelectorAll('.faq_item').forEach((item, index) => {
    const header = item.querySelector('.faq_header');
    const body = item.querySelector('.faq_body');
    if (!header || !body) return;
    header.id = 'faq-question-' + index;
    body.id = 'faq-answer-' + index;
    header.setAttribute('role', 'button');
    header.setAttribute('tabindex', '0');
    header.setAttribute('aria-controls', body.id);
    body.setAttribute('role', 'region');
    body.setAttribute('aria-labelledby', header.id);
    header.setAttribute('aria-expanded', String(item.dataset.accordionStatus === 'active'));
    const toggle = () => {
      const wasOpen = item.dataset.accordionStatus === 'active';
      document.querySelectorAll('.faq_item').forEach((sibling) => {
        const open = sibling === item && !wasOpen;
        sibling.dataset.accordionStatus = open ? 'active' : 'not-active';
        sibling.querySelector('.faq_header')?.setAttribute('aria-expanded', String(open));
      });
    };
    header.addEventListener('click', toggle);
    header.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        toggle();
      }
    });
  });

  // Keep the original touch-friendly horizontal sliders on smaller screens.
  const sliders = [];
  function initializeSliders() {
    sliders.forEach((slider) => slider.destroy(true, true));
    sliders.length = 0;
    if (typeof window.Swiper !== 'function') return;
    const how = document.querySelector('.how-work-swiper');
    if (how) {
      sliders.push(new window.Swiper(how, {
        slidesPerView: 1.1,
        spaceBetween: 20,
        grabCursor: true,
        pagination: { el: how.querySelector('.swiper-pagination'), type: 'progressbar' },
        breakpoints: { 768: { slidesPerView: 1.1, centeredSlides: true }, 992: { slidesPerView: 3, allowTouchMove: false } },
      }));
    }
    if (window.innerWidth <= 991) {
      document.querySelectorAll('.plan-swiper, .pricing-swiper, .account-swiper').forEach((element) => {
        sliders.push(new window.Swiper(element, {
          slidesPerView: element.classList.contains('plan-swiper') ? 1 : 'auto',
          spaceBetween: 10,
          grabCursor: true,
          pagination: { el: element.querySelector('.swiper-pagination'), type: 'progressbar' },
        }));
      });
    }
  }
  initializeSliders();
  let resizeTimer;
  let sliderWidth = window.innerWidth;
  window.addEventListener('resize', () => {
    if (sliderWidth === window.innerWidth) return;
    sliderWidth = window.innerWidth;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(initializeSliders, 180);
  });

  const cards = document.querySelectorAll('.how-it-work_item-link');
  cards.forEach((card) => {
    const activate = () => cards.forEach((item) => item.classList.toggle('is-active', item === card));
    card.addEventListener('mouseenter', activate);
    card.addEventListener('focusin', activate);
    card.addEventListener('mouseleave', () => {
      cards.forEach((item, index) => item.classList.toggle('is-active', index === 0));
    });
  });

  // Marquee copies are decorative and do not repeat content to screen readers.
  document.querySelectorAll('[data-css-marquee]').forEach((marquee) => {
    const list = marquee.querySelector('[data-css-marquee-list]');
    if (!list) return;
    const copy = list.cloneNode(true);
    copy.setAttribute('aria-hidden', 'true');
    marquee.appendChild(copy);
  });

  if (!reducedMotion && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.05 });
    document.querySelectorAll('section .heading-wrapper, section .content-wrapper, .pricing_component').forEach((element) => {
      if (element.getBoundingClientRect().top > window.innerHeight) {
        element.classList.add('reveal-ready');
        observer.observe(element);
      }
    });
  }

  const heroVideo = document.querySelector('.section_hero video');
  if (heroVideo && reducedMotion) {
    heroVideo.pause();
    heroVideo.removeAttribute('autoplay');
  }

  // No server-side email delivery is claimed: the visitor completes sending.
  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const value = (name) => String(form.elements.namedItem(name).value).trim();
    const subject = 'Whoosh Performance — ' + value('interest');
    const body = [
      'Name: ' + value('name'),
      'Email: ' + value('email'),
      'Business: ' + value('business'),
      'Interested in: ' + value('interest'),
      '',
      value('message'),
    ].join('\n');
    const mailto = 'mailto:' + CONTACT_EMAIL + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
    status.textContent = 'Your email draft is ready. Complete sending in your email app. If it did not open, email ' + CONTACT_EMAIL + ' directly.';
    window.location.href = mailto;
  });

  document.querySelectorAll('[data-policy]').forEach((link) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      const id = link.dataset.policy === 'refund-cancellation' ? 'terms-and-conditions' : link.dataset.policy;
      const dialog = document.getElementById(id);
      if (!(dialog instanceof HTMLDialogElement)) return;
      previouslyFocused = link;
      dialog.showModal();
      if (link.dataset.policy === 'refund-cancellation') {
        const heading = Array.from(dialog.querySelectorAll('h2, h3, h4')).find((element) => /refund|cancellation/i.test(element.textContent));
        heading?.scrollIntoView({ block: 'start' });
      } else dialog.scrollTop = 0;
    });
  });
  document.querySelectorAll('.policy-dialog').forEach((dialog) => {
    dialog.querySelector('[data-close-policy]')?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => {
      const bounds = dialog.getBoundingClientRect();
      if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
    });
    dialog.addEventListener('close', () => previouslyFocused?.focus());
  });
})();
