"""Create the user-requested Whoosh Performance page from the supplied reference.

The supplied page is retained as a design/content reference only. Production files
contain no original tracking scripts, contact details, or outbound sales links.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import urlparse, unquote
from typing import Any
import hashlib
import json
import re
import requests
from bs4 import BeautifulSoup, Comment

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'public'
ASSETS = PUBLIC / 'assets'
ASSETS.mkdir(parents=True, exist_ok=True)
EMAIL = 'info@whooshperformance.com'
ORIGIN = 'https://www.whooshperformance.com'
source = (ROOT / 'reference/original.html').read_text()
# Imported HTML is a heterogeneous DOM rather than a statically typed tree.
p: Any = BeautifulSoup(source, 'html.parser')
assert p.html is not None and p.head is not None and p.body is not None
css = (ROOT / 'reference/original.css').read_text()

# Remove original analytics, Webflow scripts, remote form routing and metadata.
for element in p.select('script, noscript, iframe'):
    element.decompose()
for comment in p.find_all(string=lambda s: isinstance(s, Comment)):
    comment.extract()
for attribute in ['data-wf-domain', 'data-wf-page', 'data-wf-site']:
    p.html.attrs.pop(attribute, None)
p.html['lang'] = 'en'
p.body['id'] = 'top'
for meta in p.select('meta[name="generator"]'):
    meta.decompose()
for element in p.select('link[rel="stylesheet"], link[rel="icon"], link[rel="apple-touch-icon"], link[rel="preconnect"]'):
    element.decompose()

# Keep the original visual assets, host copies rather than hotlinking site files.
urls = set()
for image in p.select('img'):
    if image.get('src', '').startswith('https://'):
        urls.add(image['src'])
    image.attrs.pop('srcset', None)
for element in p.select('[poster], source[src], link[rel="preload"]'):
    attr = 'poster' if element.has_attr('poster') else 'src' if element.has_attr('src') else 'href'
    if element.get(attr, '').startswith('https://'):
        urls.add(element[attr])
for url in re.findall(r'url\([\"\']?(https://[^)\"\']+)', css):
    urls.add(url)
vendors = {
    'swiper.min.css': 'https://cdn.jsdelivr.net/npm/swiper@11.2.10/swiper-bundle.min.css',
    'swiper.min.js': 'https://cdn.jsdelivr.net/npm/swiper@11.2.10/swiper-bundle.min.js',
}
for url in vendors.values():
    urls.add(url)

names = {}
for url in urls:
    vendor_name = next((name for name, vendor_url in vendors.items() if url == vendor_url), None)
    if vendor_name:
        name = vendor_name
    elif 'vimeo.com' in url:
        name = 'hero-gold.mp4'
    else:
        base = unquote(urlparse(url).path.rsplit('/', 1)[-1])
        clean = re.sub(r'[^a-zA-Z0-9._-]', '-', base)
        name = clean[:180] or hashlib.sha256(url.encode()).hexdigest()[:12]
    names[url] = name


def download(url):
    target = ASSETS / names[url]
    if not target.exists():
        response = requests.get(url, timeout=90)
        response.raise_for_status()
        target.write_bytes(response.content)
    return url, '/assets/' + names[url], target.stat().st_size

mapping = {}
with ThreadPoolExecutor(max_workers=8) as pool:
    futures = {pool.submit(download, url): url for url in urls}
    for future in as_completed(futures):
        url, path, size = future.result()
        mapping[url] = path
        print(f'Saved {path}: {size:,} bytes', flush=True)

for element in p.find_all(True):
    for attr in ['src', 'poster', 'href']:
        value = element.get(attr)
        if value in mapping:
            element[attr] = mapping[value]
for old, new in mapping.items():
    css = css.replace(old, new)
(PUBLIC / 'reference.css').write_text(css)

# Brand names in visible text and image accessibility labels.
for text in list(p.find_all(string=True)):
    if text.parent.name == 'style':
        continue
    replaced = re.sub(r'Whoosh\s+Health', 'Whoosh Performance', str(text), flags=re.I)
    replaced = re.sub(r'Whoosh\s+Wellness', 'Whoosh Performance', replaced, flags=re.I)
    if replaced != str(text):
        text.replace_with(replaced)
for image in p.select('img[alt]'):
    image['alt'] = re.sub(r'Whoosh\s+(Health|Wellness)', 'Whoosh Performance', image['alt'], flags=re.I)

# Preserve the distinctive original WHOOSH paths, replacing only the lower name.
for selector, y, x, size, length in [('.logo-icon', 17, 1, 6.3, 56), ('.footer-logo', 321, 20, 124, 1120)]:
    svg = p.select_one(selector)
    groups = svg.find_all('g', recursive=False)
    if len(groups) > 1:
        groups[1].decompose()
    title = p.new_tag('title')
    title.string = 'Whoosh Performance'
    svg.insert(0, title)
    svg['role'] = 'img'
    svg['aria-label'] = 'Whoosh Performance'
    text = BeautifulSoup(
        f'<text x="{x}" y="{y}" fill="currentColor" font-family="Arial, sans-serif" font-size="{size}" '
        f'font-weight="700" font-style="italic" textLength="{length}" lengthAdjust="spacingAndGlyphs">PERFORMANCE</text>',
        'html.parser').find('text')
    assert text is not None
    svg.append(text)
logo = p.select_one('[data-menu-logo]')
logo['aria-label'] = 'Whoosh Performance — back to top'

# Email-only contact. No original company address or phone element remains.
for contact in list(p.select('.contact-item')):
    email = contact.select_one('a[href^="mailto:"]')
    if email:
        email['href'] = 'mailto:' + EMAIL
        email.string = EMAIL
    else:
        contact.decompose()
for credit in p.select('.copyright-text'):
    credit.clear()
    credit.string = '© 2026 Whoosh Performance. All rights reserved.'

# The homepage is the whole website: all sales/navigation actions stay here.
p.select_one('.section_pricing')['id'] = 'pricing'
for anchor in p.select('a[href]'):
    href = anchor['href']
    label = anchor.get_text(' ', strip=True).lower()
    if href.startswith('/#'):
        anchor['href'] = href[1:]
    elif href == '/':
        anchor['href'] = '#top'
    elif 'calendly.com' in href:
        anchor['href'] = '#contact'
        anchor['data-inquiry'] = 'Book a demo'
    elif href == '/pricing':
        if 'choose base' in label or 'choose pro' in label:
            plan = 'Base Account' if 'base' in label else 'Pro Account'
            anchor['href'] = '#contact'
            anchor['data-inquiry'] = plan
        elif 'explore pricing' in label or label == 'pricing':
            anchor['href'] = '#pricing'
        else:
            anchor['href'] = '#contact'
            anchor['data-inquiry'] = 'Become a partner'
    elif href.startswith('/privacy-policy'):
        anchor['href'] = '#privacy-policy'
        anchor['data-policy'] = 'privacy-policy'
    elif href.startswith('/terms-and-conditions'):
        policy = 'refund-cancellation' if 'refund' in label else 'terms-and-conditions'
        anchor['href'] = '#' + policy
        anchor['data-policy'] = policy
    anchor.attrs.pop('target', None)

# Explicitly disclose the mailto contact behavior instead of inventing delivery.
form = BeautifulSoup('''
<div class="performance-contact">
  <div class="performance-contact-intro">
    <div class="sub-heading">LET’S BUILD SOMETHING TOGETHER</div>
    <h2 class="heading-style-h2">Ready to launch?</h2>
    <p>Tell us about your business. We’ll help you choose your path to launch.</p>
  </div>
  <form id="inquiry-form" class="inquiry-form" aria-label="Contact Whoosh Performance">
    <div class="inquiry-fields">
      <label>Your name<input name="name" autocomplete="name" placeholder="Full name" required maxlength="100"/></label>
      <label>Email address<input name="email" type="email" autocomplete="email" placeholder="you@company.com" required maxlength="254"/></label>
      <label>Business name<input name="business" autocomplete="organization" placeholder="Your business" maxlength="150"/></label>
      <label>I’m interested in<select name="interest"><option>Become a partner</option><option>Book a demo</option><option>Base Account</option><option>Pro Account</option><option>General inquiry</option></select></label>
    </div>
    <label>Your message<textarea name="message" rows="3" placeholder="Tell us a little about your goals…" required maxlength="3000"></textarea></label>
    <div class="inquiry-submit-row">
      <button class="primary-button inquiry-button" type="submit">Send inquiry <span aria-hidden="true">↗</span></button>
      <p class="inquiry-note">Opens your email app with a message to <a href="mailto:info@whooshperformance.com">info@whooshperformance.com</a>. Send it there to complete your inquiry.</p>
    </div>
    <p class="inquiry-status" id="inquiry-status" role="status" aria-live="polite"></p>
  </form>
</div>''', 'html.parser')
container = p.select_one('.footer .container-large')
container.insert(0, form)

# Retain policy access without introducing more landing-page routes.
# Policy copy is sourced from the supplied site, rebranded and stripped of old contact data.
for name, policy_id, label in [('privacy', 'privacy-policy', 'Privacy Policy'), ('terms', 'terms-and-conditions', 'Terms and Conditions')]:
    policy_page: Any = BeautifulSoup((ROOT / f'reference/{name}.html').read_text(), 'html.parser')
    rich = policy_page.select_one('.w-richtext')
    assert rich is not None, f'Missing reference policy copy: {name}'
    for text in list(rich.find_all(string=True)):
        value = re.sub(r'Whoosh\s+(Health|Wellness|Holding Co\.?\s*LLC)', 'Whoosh Performance', str(text), flags=re.I)
        value = re.sub(r'[a-zA-Z0-9._%+-]+@(?:whooshwellness\.com|whoosh\.health)', EMAIL, value)
        value = re.sub(r'(?:(?:https?://)?(?:www\.)?)whoosh\.(?:health)', ORIGIN, value, flags=re.I)
        value = re.sub(r'(?:https?://)?(?:www\.)?whooshwellness\.com', ORIGIN, value, flags=re.I)
        if value != str(text):
            text.replace_with(value)
    for item in list(rich.select('p, li')):
        if re.search(r'508\s*30|Newport\s*Beach|92663|512.{0,6}705|street address|mailing address', item.get_text(), re.I):
            item.decompose()
    for anchor in rich.select('a[href]'):
        href = anchor['href']
        if href.startswith('tel:'):
            anchor.decompose()
        elif href.startswith('mailto:'):
            anchor['href'] = 'mailto:' + EMAIL
            anchor.string = EMAIL
        elif any(host in href for host in ['whooshwellness.com', 'whoosh.health']):
            anchor['href'] = '#contact'
    rich['class'] = ['text-rich-text', 'policy-copy']
    dialog = p.new_tag('dialog', id=policy_id)
    dialog['class'] = ['policy-dialog']
    dialog['aria-label'] = label
    close = p.new_tag('button', type='button')
    close['class'] = ['policy-close']
    close['aria-label'] = 'Close ' + label
    close['data-close-policy'] = ''
    close.string = 'Close ×'
    dialog.append(close)
    dialog.append(rich)
    p.body.append(dialog)

# Fresh metadata, with no original organization contact info.
p.title.string = 'Whoosh Performance | White-Label Telehealth Storefronts'
for meta in p.select('meta[property="og:title"], meta[name="twitter:title"]'):
    meta['content'] = p.title.string
hero_poster = p.select_one('video')['poster']
for meta in p.select('meta[property="og:image"]'):
    meta['content'] = ORIGIN + hero_poster
for name, value, kind in [('og:site_name', 'Whoosh Performance', 'property'), ('og:url', ORIGIN + '/', 'property'), ('twitter:image', ORIGIN + hero_poster, 'name'), ('keywords', 'Whoosh Performance, telehealth, white-label wellness, wellness storefronts', 'name')]:
    p.head.append(p.new_tag('meta', attrs={kind: name, 'content': value}))
p.head.append(p.new_tag('link', rel='canonical', href=ORIGIN + '/'))
font_url = '/assets/6ab433c332e14fd711196764_davidlibre.woff2'
p.head.append(p.new_tag('link', attrs={'rel': 'preload', 'href': font_url, 'as': 'font', 'type': 'font/woff2', 'crossorigin': 'anonymous'}))
for href in ['/reference.css', '/assets/swiper.min.css', '/performance.css']:
    p.head.append(p.new_tag('link', rel='stylesheet', href=href))
p.head.append(p.new_tag('link', rel='icon', href='/favicon.svg', type='image/svg+xml'))
for src in ['/assets/swiper.min.js', '/performance.js']:
    p.body.append(p.new_tag('script', src=src, defer=''))
structured = p.new_tag('script', type='application/ld+json')
structured.string = json.dumps({'@context': 'https://schema.org', '@type': 'Organization', 'name': 'Whoosh Performance', 'url': ORIGIN, 'email': EMAIL, 'description': 'White-label telehealth storefronts for wellness brands.'})
p.head.append(structured)

# Avoid loading a large video file before the important hero content.
video = p.select_one('video')
video['preload'] = 'none'
video['aria-hidden'] = 'true'
for image in p.select('img'):
    image['decoding'] = 'async'

(PUBLIC / 'index.html').write_text(p.prettify())
(PUBLIC / 'manus-routes.json').write_text(json.dumps({'routes': [{'path': '/', 'title': 'Whoosh Performance'}]}) + '\n')
(PUBLIC / 'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: ' + ORIGIN + '/sitemap.xml\n')
(PUBLIC / 'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>' + ORIGIN + '/</loc></url></urlset>\n')
(ROOT / 'reference/assets.json').write_text(json.dumps(mapping, indent=2))
print('Landing page created with', len(mapping), 'local assets.', flush=True)
